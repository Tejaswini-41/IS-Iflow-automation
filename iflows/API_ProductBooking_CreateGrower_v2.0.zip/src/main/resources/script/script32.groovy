import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Retrieve the sfresponse property
    def sfresponse = message.getProperty("sfresponse")
    
    // Parse the JSON string into a Groovy object
    def jsonSlurper = new JsonSlurper()
    def response = jsonSlurper.parseText(sfresponse)
    
    // Process the data
    def result = response.collectMany { value ->
        value.productItem.collect { item ->
            def reqSynOrdNum = value.reqSynOrdNum
            if (reqSynOrdNum?.startsWith("SO-")) {
                if (reqSynOrdNum.size() > 18) {
                    reqSynOrdNum = reqSynOrdNum.substring(reqSynOrdNum.indexOf("-20") + 3)
                } else {
                    reqSynOrdNum = reqSynOrdNum.substring(reqSynOrdNum.indexOf("-20") + 3)
                }
            }
            
            [
                reqCustOrdNum: value.reqCustOrdNum ?: "",
                reqCustOrdLineNum: item.reqCustOrdLineNum ?: "",
                reqSynOrdNum: reqSynOrdNum ?: value.reqSynOrdNum,
                reqSynOrdLineNum: item.reqSynOrdLineNum ?: "",
                reqProdGTIN: item.reqProdGTIN ?: "",
                reqProdQty: item.reqProdQty != null ? String.format("%.3f", item.reqProdQty.toDouble()) : null,
                reqRDD: item.reqRDD ?: "",
                reqType: item.reqType ?: "",
                respAvailProdQty: item.respAvailProdQty != null ? String.format("%.3f", item.respAvailProdQty.toDouble()) : null,
                respExceptions: value.respExceptions instanceof List ? value.respExceptions : [],
                respExceptionsLine: item.respExceptions ?: "",
                reqProdQtyDelta: item.reqProdQtyDelta != null ? String.format("%.3f", item.reqProdQtyDelta.toDouble()) : null,
                respAvailStatus: item.respAvailStatus ?: "",
                respLongShortQty: item.respLongShortQty != null ? String.format("%.3f", Math.abs(item.respLongShortQty.toDouble())) : null,
                reqM2MOrderRef: item.reqM2MOrderRef ?: "",
                respSpcInstr: value.respSpcInstr ?: "",
                respProdName: item.respProdName ?: "",
                respPOQty: (item.respPOQty == null && item.respBOQty == null) ? null : 
                           String.format("%.3f", ((item.respPOQty?.abs()?.toDouble() ?: 0.0) + (item.respBOQty?.abs()?.toDouble() ?: 0.0))),
                respTotalPOQty: (item.respTotalPOQty == null && item.respTotalBOQty == null) ? null : 
                                String.format("%.3f", ((item.respTotalPOQty?.toDouble() ?: 0.0) + (item.respTotalBOQty?.toDouble() ?: 0.0))),
                respTotalGrowerQty: item.respTotalGrowerQty != null ? String.format("%.3f", item.respTotalGrowerQty.toDouble()) : null
            ]
        }
    }
    
    // Wrap the result in a root element for proper XML conversion
    def wrappedResult = [response: result]
    
    // Convert the result back to JSON with pretty print
    def jsonOutput = JsonOutput.prettyPrint(JsonOutput.toJson(wrappedResult))
    message.setBody(jsonOutput)
    
    return message
}