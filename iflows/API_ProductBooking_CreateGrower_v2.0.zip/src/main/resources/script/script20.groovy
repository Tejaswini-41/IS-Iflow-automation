import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def body = message.getBody(String)
    def validateGLN = new JsonSlurper().parseText(body)
    def setErrorList = new JsonSlurper().parseText(message.getProperty("setErrorList"))

    def updatedErrorList = setErrorList.collect { item ->
        // Check if the GrowerGLN exists in the validateGLN list
        def isValidGLN = validateGLN.any { it.GLN == item.GrowerGLN }
        
        // If the GLN is not valid, add the error to the HeaderError list
        if (!isValidGLN) {
            item.HeaderError = item.HeaderError ?: [] // Ensure HeaderError is initialized as an empty list if null
            item.HeaderError << [
                "id": "107",
                "description": "Ship To Partner Identifier Is Not A Valid AGIIS GLN",
                "comments": "Ship To Partner Identifier Must Be A Valid Ag Industry Identification System (AGIIS) Global Location Number (GLN)"
            ]
        }
        
        return [
            "reqCustOrdNum": item.reqCustOrdNum,
            
            "GrowerGLN": item.GrowerGLN,
            "ActualGrowerGLN":item.ActualGrowerGLN,
            "HeaderError": item.HeaderError,
            "productItem": item.productItem
        ]
    }

    def result = JsonOutput.prettyPrint(JsonOutput.toJson(updatedErrorList))
    message.setProperty("setErrorList", result)
    return message
}