import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Retrieve the input payload from the message body
    def body = message.getBody(java.lang.String) as String
    body = body.replaceAll(/<\?xml.*?\?>\s*/, '').trim()

    // Build the XML structure
    def xml = """<?xml version='1.0' encoding='UTF-8'?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
  <soapenv:Header/>
  <soapenv:Body>
    <ag:outboundData xmlns:ag="urn:aggateway:names:ws:docexchange">
      <ag:processStep>ProductBookingResponse</ag:processStep>
      <ag:messageId>0</ag:messageId>
      <ag:xmlPayload>
      ${body}
      </ag:xmlPayload>
    </ag:outboundData>
  </soapenv:Body>
</soapenv:Envelope>"""

    // Set the generated XML as the message body
    message.setBody(xml.toString())
    message.setHeader("Content-Type", "application/xml")

    return message
}