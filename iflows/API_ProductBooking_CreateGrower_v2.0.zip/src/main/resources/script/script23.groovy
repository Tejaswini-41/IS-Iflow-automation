import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Parse the incoming body and property
    def payload = new JsonSlurper().parseText(message.getBody(String))
    def setErrorList = new JsonSlurper().parseText(message.getProperty("setErrorList"))

    // Function to add grower details
    def addGrower = { grower ->
        payload.growers.find { it.gln == grower }
    }

    // Filter growers
    def filteredGrowers = payload.growers.findAll { 
        (it.agiisStatus == "Active" || it.agiisStatus == "Inactive") && !it.sfdcid 
    }

    // Map order details
    def orderDetail = setErrorList.collect { item ->
        def growerDetails = addGrower(item.GrowerGLN)
        [
            "reqCustOrdNum": item.reqCustOrdNum,
            "GrowerGLN": item.GrowerGLN,
            "ActualGrowerGLN":item.ActualGrowerGLN,
            "reqDocIdentifier": growerDetails?.reqDocIdentifier ?: "",
            "growerSFDCId": growerDetails?.sfdcid ?: "",
            "growerSFDCStatus": growerDetails?.sfdcStatus ?: "",
            "HeaderError": item.HeaderError,
            "productItem": item.productItem
        ]
    }

    // Create the final output
    def result = [
        "resellerGLN": payload.resellerGlN,
        "growers": filteredGrowers,
        "orderDetail": orderDetail
    ]

    // Convert the result to JSON and set it as the message body
    def jsonResult = JsonOutput.prettyPrint(JsonOutput.toJson(result))
    // message.setBody(jsonResult)
    message.setProperty("setErrorList",jsonResult)
    
    return message
}