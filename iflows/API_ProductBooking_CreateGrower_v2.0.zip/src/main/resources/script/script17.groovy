import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    // Retrieve properties
    def body = message.getBody(String)
    def payload = new JsonSlurper().parseText(body)
    def auth_query2 = message.getProperty("auth_query2")
    def auth_query2_1 = message.getProperty("auth_query2_1")
    def auth_pal_query3 = message.getProperty("auth_pal_query3")
    def auth_query4 = message.getProperty("auth_query4")

    // Retrieve variables
    def query1 = message.getProperty("query1")
    def query2 = message.getProperty("query2")
    def query3 = message.getProperty("query3")
    // Parse the incoming JSON payload
    // println payload.result.compositeResponse[0].body.totalSize
    // println auth_query2_1
    // Determine the message based on conditions
    def resultMessage
    if (query1 == "false" && payload.result.compositeResponse[0].body.totalSize.toInteger() < 1) {
        resultMessage = auth_query2
    } else if (query1 == "false" && payload.result.compositeResponse[0].body.totalSize.toInteger() > 1) {
        resultMessage = auth_query2_1
    } else if (query2 == "false") {
        resultMessage = auth_query2
    } else if (query3 == "false") {
        resultMessage = auth_pal_query3
    } else {
        resultMessage = auth_query4
    }

    // Set the result message
    message.setBody(resultMessage)
    message.setProperty("RequiredField",resultMessage)
  
    return message
}