import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def properties = message.getProperties()
    
    def CheckEG = new JsonSlurper().parseText(properties.get("CheckEG"))
    def GtinStatus = new JsonSlurper().parseText(properties.get("GtinStatus"))
    def setErrorList = new JsonSlurper().parseText(properties.get("setErrorList"))
    def ErrorCodes = new JsonSlurper().parseText(properties.get("ErrorCodes"))

    def addcheckEG = { GTIN ->
        CheckEG.findAll { it.status == false }
    }

    def addGtinStatus = { GTIN ->
        GtinStatus.findAll { it.status == false }*.GTIN
    }

    def result = [
        resellerGLN: setErrorList.resellerGLN,
        growers: setErrorList.growers,
        orderDetail: setErrorList.orderDetail.collect { item ->
            [
                reqCustOrdNum: item.reqCustOrdNum,
                GrowerGLN: item.GrowerGLN,
                ActualGrowerGLN:item.ActualGrowerGLN,
                reqDocIdentifier: item.reqDocIdentifier,
                growerSFDCId: item.growerSFDCId,
                growerSFDCStatus: item.growerSFDCStatus,
                HeaderError: item.HeaderError,
                productItem: item.productItem.collect { item1 ->
                    def lineError = item1.LineError
                    def gtin = item1.GTIN
                    def addCheckEGResult = addcheckEG(gtin)
                    def addGtinStatusResult = addGtinStatus(gtin)
                    
                    if ((addCheckEGResult.GTIN?.contains(gtin) || addCheckEGResult.OriginalGTIN?.contains(gtin)) || addGtinStatusResult.contains(gtin)) {
                        if ((addCheckEGResult.GTIN?.contains(gtin) || addCheckEGResult.OriginalGTIN?.contains(gtin)) && addGtinStatusResult.contains(gtin)) {
                            lineError += [
                                [id: "030", description: ErrorCodes.EC030.split("-")[0], comments: ErrorCodes.EC030.split("-")[1]],
                                [id: "028", description: ErrorCodes.EC028.split("-")[0], comments: ErrorCodes.EC028.split("-")[1]]
                            ]
                        } else if (addGtinStatusResult.contains(gtin)) {
                            lineError += [
                                [id: "030", description: ErrorCodes.EC030.split("-")[0], comments: ErrorCodes.EC030.split("-")[1]]
                            ]
                        } else {
                            lineError += [
                                [id: "028", description: ErrorCodes.EC028.split("-")[0], comments: ErrorCodes.EC028.split("-")[1]]
                            ]
                        }
                    }
                    
                    [
                        GTIN: gtin,
                        reqCustOrdLineNum: item1.reqCustOrdLineNum,
                        LineError: lineError
                    ]
                }
            ]
        }
    ]

    def formattedJson = JsonOutput.prettyPrint(JsonOutput.toJson(result))
    message.setProperty("setErrorList", formattedJson)
    return message
}