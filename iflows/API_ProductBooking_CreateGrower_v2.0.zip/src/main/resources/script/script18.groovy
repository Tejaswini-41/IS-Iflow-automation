import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Retrieve properties
    def growerGLN = message.getProperty("newGrowerGLNSeperatedcommas")
    // println "growerGLN: ${growerGLN}"
    // Parse the incoming JSON payload
    def body = message.getBody(String)
    
    // Check if the body is empty or null
    if (!body) {
        message.setBody("{}")
        return message
    }
    
    def jsonSlurper = new JsonSlurper()
    def payload = jsonSlurper.parseText(body)

    // Ensure growerGLN is a list of strings
    if (!(growerGLN instanceof List)) {
        growerGLN = growerGLN.split(',').collect { it.trim() }
    } else {
        growerGLN = growerGLN.collect { it.toString() }
    }
    // println "Processed growerGLN: ${growerGLN}"

    // Helper functions
    def getStatus = { gln ->
        if (payload.value instanceof String || payload.value == null) {
            return "Inactive"
        } else {
            def entityInfo = payload.value.collectMany { it.body.entitySearchOutboundDetails }.findAll {
                it.entityInformation.industryIdentifier.any { id -> id.industryCode == gln }
            }
            return entityInfo?.entityInformation?.activeFlag?.getAt(0) ?: "Inactive"
        }
    }

    def getGrowerAddress = { gln ->
        if (payload.value instanceof String || payload.value == null) {
            return [:]
        } else {
            return payload.value.collectMany { it.body.entitySearchOutboundDetails }.findAll {
                it.entityInformation.industryIdentifier.any { id -> id.industryCode == gln }
            }?.getAt(0) ?: [:]
        }
    }

    def getCountry = { state ->
        if (!state) return ""
        def canadianProvinces = ['NL', 'PE', 'NS', 'NB', 'QC', 'ON', 'MB', 'SK', 'AB', 'BC', 'YT', 'NT', 'NU']
        return canadianProvinces.contains(state) ? 'CA' : 'US'
    }

    def swap = { add, alter ->
        return add ?: alter
    }

    // Debugging output
    payload.value.each { println it.body.entitySearchOutboundDetails.entityInformation.industryIdentifier.industryCode }

    // Process each GLN
    def results = growerGLN.collect { gln ->
        def growerAddress = getGrowerAddress(gln)
        def exists = payload.value.collectMany { it.body.entitySearchOutboundDetails }.any {
            it.entityInformation.industryIdentifier.any { id -> id.industryCode == gln }
        }
        println "GLN: ${gln}, Exists: ${exists}"
        [
            exists: exists,
            active: getStatus(gln),
            GLN: gln,
            propId: growerAddress?.entityInformation?.industryIdentifier?.find { it.industryCode == gln }?.proprietaryCode ?: "",
            growerName: growerAddress?.entityInformation?.preferredName ?: "",
            growerFirstName: growerAddress?.entityInformation?.individualName?.firstName ?: "",
            growerLastName: growerAddress?.entityInformation?.individualName?.lastName ?: "",
            growerMailAddrLine: swap(growerAddress?.entityInformation?.mailingAddress?.addressLine1 ?: "", growerAddress?.entityInformation?.physicalAddress?.addressLine1 ?: ""),
            growerMailCity: swap(growerAddress?.entityInformation?.mailingAddress?.cityName ?: "", growerAddress?.entityInformation?.physicalAddress?.cityName ?: ""),
            growerMailState: swap(growerAddress?.entityInformation?.mailingAddress?.stateOrProvince ?: "", growerAddress?.entityInformation?.physicalAddress?.stateOrProvince ?: ""),
            growerMailPostalCode: swap(growerAddress?.entityInformation?.mailingAddress?.postalCode ?: "", growerAddress?.entityInformation?.physicalAddress?.postalCode ?: ""),
            growerMailCountry: swap(
                growerAddress?.entityInformation?.mailingAddress?.postalCountry ?: getCountry(growerAddress?.entityInformation?.mailingAddress?.stateOrProvince ?: ""),
                growerAddress?.entityInformation?.physicalAddress?.postalCountry ?: getCountry(growerAddress?.entityInformation?.physicalAddress?.stateOrProvince ?: "")
            ),
            growerShipAddrLine: swap(growerAddress?.entityInformation?.physicalAddress?.addressLine1 ?: "", growerAddress?.entityInformation?.mailingAddress?.addressLine1 ?: ""),
            growerShipCity: swap(growerAddress?.entityInformation?.physicalAddress?.cityName ?: "", growerAddress?.entityInformation?.mailingAddress?.cityName ?: ""),
            growerShipState: swap(growerAddress?.entityInformation?.physicalAddress?.stateOrProvince ?: "", growerAddress?.entityInformation?.mailingAddress?.stateOrProvince ?: ""),
            growerShipPostalCode: swap(growerAddress?.entityInformation?.physicalAddress?.postalCode ?: "", growerAddress?.entityInformation?.mailingAddress?.postalCode ?: ""),
            growerShipCountry: swap(
                growerAddress?.entityInformation?.physicalAddress?.postalCountry ?: getCountry(growerAddress?.entityInformation?.physicalAddress?.stateOrProvince ?: ""),
                growerAddress?.entityInformation?.mailingAddress?.postalCountry ?: getCountry(growerAddress?.entityInformation?.mailingAddress?.stateOrProvince ?: "")
            ),
            isPerson: growerAddress?.entityInformation?.entityClassifications?.contains("Consumer") ?: false
        ]
    }

     // Set the result message
    def resultJson = JsonOutput.toJson(results)
    message.setBody(resultJson)
    message.setProperty("validateGLN", resultJson)
    return message
}