import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    // Retrieve the input payload from the message body
    def body = message.getBody(java.lang.String) as String
    body = body.replaceAll(/<\?xml.*?\?>\s*/, '').trim()
    // Parse the body content into an XML structure
    def payload = new XmlSlurper().parseText(body)
    def properties = message.getProperties()
    def businessProcess = properties.get("businessProcess")
    // Create a StringWriter to hold the XML
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    def process = ""
    if(businessProcess == "ProductBookingWS53"){
        process = "ProductBookingResponse"
    }
    else{
         process = "ProductBookingResponse"
    }
     // Build the XML structure
    def xml1 = """<?xml version='1.0' encoding='UTF-8'?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
  <soapenv:Header/>
  <soapenv:Body>
    <ag:outboundData xmlns:ag="urn:aggateway:names:ws:docexchange">
      <ag:processStep>$process</ag:processStep>
      <ag:messageId>0</ag:messageId>
      <ag:xmlPayload>
      ${body}
      </ag:xmlPayload>
    </ag:outboundData>
  </soapenv:Body>
</soapenv:Envelope>"""

    // Set the generated XML as the message body
    message.setBody(xml1.toString())
    message.setHeader("Content-Type", "application/xml")

    return message
}