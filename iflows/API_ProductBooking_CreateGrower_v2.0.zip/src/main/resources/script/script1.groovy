import com.sap.gateway.ip.core.customdev.util.Message

import groovy.json.JsonBuilder

def Message processData(Message message) {
    // Get the body of the message
    def body = message.getBody(String)
    message.setProperty("InputPayload", body)
    
    // Parse the XML
    def xml = new XmlSlurper().parseText(body)
    
    // Extract the Username value
    def username = xml.Header.Security.UsernameToken.Username.text()
    
    // Extract the businessProcess value
    def businessProcess = xml.Body.inboundData.businessProcess.text()
    
    def password = xml.Header.Security.UsernameToken.Password.text()
    
    // Check the condition and extract the appropriate payload
    def xmlPayload
    if (xml.Body.inboundData != null) {
        xmlPayload = xml.Body.inboundData.xmlPayload
    } else {
        xmlPayload = xml.Body
    }
    
    // Convert the XML payload to a map dynamically
    def payloadMap = convertXmlToMap(xmlPayload)
    
    // Convert the map to JSON format
    def jsonPayload = new JsonBuilder(payloadMap).toPrettyString()
    
    // Store the values in properties
    message.setProperty("Username", username)
    message.setProperty("businessProcess", businessProcess)
    message.setProperty("password",password)
    
    // Set the JSON payload as the body
    message.setBody(jsonPayload)
    message.setHeader("Content-Type","application/json")
    message.setProperty("formattedInputBody",jsonPayload)
    return message
}

// Helper function to convert XML to a map dynamically
def convertXmlToMap(node) {
    def map = [:]
    node.children().each { child ->
        def key = child.name()
        def value
        if (child.children().size() > 0) {
            value = convertXmlToMap(child)
        } else {
            value = child.text()
        }
        if (map.containsKey(key)) {
            if (map[key] instanceof List) {
                map[key] << value
            } else {
                map[key] = [map[key], value]
            }
        } else {
            map[key] = value
        }
    }
    return map
}
