import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Parse the CheckEG property
    def checkEGJson = message.getProperty("CheckEG")
    def checkEGList = new JsonSlurper().parseText(checkEGJson)
    
    // Process the CheckEG data and generate the output
    def checkEGOutput = checkEGList.collect { item ->
        [
            status: (item.Brands == "EG" && item.enogenDealer == "yes") || (item.Brands != "EG"),
            GTIN: item.GTIN,
            OriginalGTIN: item.OriginalGTIN
        ]
    }
    
    // Parse the GTIN property
    def gtinJson = message.getProperty("GTIN")
    def gtinList = new JsonSlurper().parseText(gtinJson)
    
    // Parse the PMRXRef_GTINs property
    def pmrxRefGtinJson = message.getProperty("PMRXRef_GTINs")
    def pmrxRefGtinList = new JsonSlurper().parseText(pmrxRefGtinJson).giic_GTIN_Number__c ?: []
    
    // Parse the product_Gtins property
    def productGtinsJson = message.getProperty("product_Gtins")
    def productGtinsList = new JsonSlurper().parseText(productGtinsJson)
    
    // Process the GTIN data and generate the output
    def gtinOutput = gtinList.collect { gtin ->
        [
            status: (pmrxRefGtinList + productGtinsList).contains(gtin),
            GTIN: gtin
        ]
    }
    
    // Set the CheckEG output as a property named ProcessedCheckEG
    def prettyCheckEGOutput = JsonOutput.prettyPrint(JsonOutput.toJson(checkEGOutput))
    message.setProperty("CheckEG", prettyCheckEGOutput)
    
    // Set the GTIN output as a property named ProcessedGTIN
    def prettyGtinOutput = JsonOutput.prettyPrint(JsonOutput.toJson(gtinOutput))
    message.setProperty("GtinStatus", prettyGtinOutput)
    
    // Check if neither GtinStatus nor CheckEG contains false in their status fields
    def isValid = !gtinOutput.any { it.status == false } && !checkEGOutput.any { it.status == false }
    
    // Set the check property
    message.setProperty("isValid", isValid)
    
    return message
}