import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def properties = message.getProperties()
    
    def setErrorList = new JsonSlurper().parseText(properties.get("setErrorList"))
    def resellerGLN = properties.get("resellerGLN")?.replaceAll("'", "") // Remove single quotes
    def seedYear = properties.get("seedYear")

    def getGrowerStatus = { custnum, Grower ->
        setErrorList.orderDetail.find { it.GrowerGLN == Grower && it.reqCustOrdNum == custnum }
    }

    def geterrorGrower = { custnum, Grower ->
        setErrorList.orderDetail.find { it.GrowerGLN == Grower && it.reqCustOrdNum == custnum }?.HeaderError
    }

    def geterrorProduct = { custnum, Grower, GTIN ->
        setErrorList.orderDetail.find { it.GrowerGLN == Grower && it.reqCustOrdNum == custnum }?.productItem?.find { it.GTIN == GTIN }?.LineError
    }

    def body = message.getBody(String)
    
    // Check if the body is empty or null
    if (!body) {
        message.setBody("{}")
        return message
    }
    
    def payload = new JsonSlurper().parseText(body)
    
    def result = [
        newGrowers: [
            resellerGLN: setErrorList.resellerGLN,
            growers: setErrorList.growers
        ],
        orderDetail: []
    ]

    def productBookings = payload.ProductBooking
    def productBookingBodies = productBookings.ProductBookingBody
    if (!(productBookingBodies instanceof List)) {
        productBookingBodies = [productBookingBodies]
    }

    productBookingBodies.each { value ->
        def reqCustOrdNum = value.ProductBookingProperties.ProductBookingOrderNumber
        def GrowerGLN = value.ProductBookingPartners.ShipTo.PartnerInformation.PartnerIdentifier
        def orderDetail = [
            reqDocIdentifier: productBookings.Header.ThisDocumentIdentifier.DocumentIdentifier ?: null,
            reqSellerGLN: resellerGLN,
            reqBuyerGLN: GrowerGLN,
            reqBuyerSFDCId: getGrowerStatus(reqCustOrdNum, GrowerGLN)?.growerSFDCId ?: getGrowerStatus(reqCustOrdNum, GrowerGLN)?.GrowerGLN,
            reqPayerGLN: value.ProductBookingPartners.Payer.PartnerInformation.PartnerIdentifier,
            reqSeedYear: seedYear,
            reqCustOrdNum: reqCustOrdNum,
            reqProdBookType: value.ProductBookingProperties.ProductBookingType,
            reqSynOrdNum: (value.ProductBookingProperties.ReferenceInformation.DocumentReference.DocumentIdentifier.startsWith("SO-") || value.ProductBookingProperties.ReferenceInformation.DocumentReference.DocumentIdentifier == "9999999999") ? value.ProductBookingProperties.ReferenceInformation.DocumentReference.DocumentIdentifier : "SO-20" + value.ProductBookingProperties.ReferenceInformation.DocumentReference.DocumentIdentifier,
            respExceptions: geterrorGrower(reqCustOrdNum, GrowerGLN) ?: [],
            productItem: []
        ]

        def productBookingDetails = value.ProductBookingDetails
        def productLineItems = productBookingDetails.ProductBookingProductLineItem
        if (!(productLineItems instanceof List)) {
            productLineItems = [productLineItems]
        }

        productLineItems.each { value1 ->
            def GTIN = value1.ProductIdentification.ProductIdentifier
            def productItem = [
                reqProdGTIN: GTIN,
                reqProdQty: value1.ProductQuantity.Measurement.MeasurementValue,
                reqType: value1.ActionRequest,
                reqRDD: value1.RequestedShipDateTime.DateTimeInformation.DateTime,
                reqCustOrdLineNum: value1.ProductBookingOrderLineItemNumber,
                reqSynOrdLineNum: value1.LineNumber,
                reqM2MOrderRef: reqCustOrdNum + "|" + value1.ProductBookingOrderLineItemNumber,
                reqProdQtyDelta: value1.IncreaseOrDecrease.ProductQuantityChange.Measurement.MeasurementValue,
                respExceptions: geterrorProduct(reqCustOrdNum, GrowerGLN, GTIN) ?: []
            ]
            orderDetail.productItem << productItem
        }

        result.orderDetail << orderDetail
    }

    message.setProperty("sfRequest", JsonOutput.prettyPrint(JsonOutput.toJson(result)))
    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(result)))
    return message
}