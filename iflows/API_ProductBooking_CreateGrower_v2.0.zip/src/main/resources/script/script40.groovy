import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def properties = message.getProperties()


// /krishna
def growerGLNArray = new JsonSlurper().parseText(properties.get("growerGLN"))
def GrowerGLN = new JsonSlurper().parseText(properties.get("growerGLN"))
    def setErrorList = new JsonSlurper().parseText(properties.get("setErrorList"))
    def resellerGLN = properties.get("resellerGLN")?.replaceAll("'", "") 
    def seedYear = properties.get("seedYear")

    // Fixed: Check if GrowerGLN array contains the Grower value
    def getGrowerStatus = { custnum, growerArray ->
        setErrorList.orderDetail.find { order ->
            // Check if reqCustOrdNum matches AND GrowerGLN is in our array
            order.reqCustOrdNum == custnum && growerArray.contains(order.GrowerGLN)
        }
    }

    def geterrorGrower = { custnum, Grower ->
        def status = getGrowerStatus(custnum, Grower)
        return status?.HeaderError
    }

    def geterrorProduct = { custnum, Grower, GTIN ->
        def status = getGrowerStatus(custnum, Grower)
        return status?.productItem?.find { it.GTIN == GTIN }?.LineError
    }

    def body = message.getBody(String)

    // Check if the body is empty or null
    if (!body) {
        message.setBody("{}")
        return message
    }

    def payload = new JsonSlurper().parseText(body)

    def result = [
        newGrowers: [
            resellerGLN: setErrorList.resellerGLN,
            growers: setErrorList.growers
        ],
        orderDetail: []
    ]

    def productBookings = payload.ProductBooking
    def productBookingBodies = productBookings.ProductBookingBody
    if (!(productBookingBodies instanceof List)) {
        productBookingBodies = [productBookingBodies]
    }

    productBookingBodies.each { value ->
        def reqCustOrdNum = value.ProductBookingProperties.ProductBookingOrderNumber
        // def GrowerGLN = value.ProductBookingPartners.ShipTo.PartnerInformation.PartnerIdentifier

        // Cache the grower status to avoid multiple lookups
        def growerStatus = getGrowerStatus(reqCustOrdNum, growerGLNArray)
        message.setProperty("growerStatus", JsonOutput.toJson(growerStatus))
        def orderDetail = [
            reqDocIdentifier: productBookings.Header.ThisDocumentIdentifier.DocumentIdentifier ?: null,
            reqSellerGLN: resellerGLN,
            // Use the first GrowerGLN from the array, or fallback to ActualGrowerGLN, or original GrowerGLN
            // reqBuyerGLN: (growerStatus?.GrowerGLN instanceof List ? growerStatus?.GrowerGLN?.getAt(0) : growerStatus?.GrowerGLN) ?: growerStatus?.ActualGrowerGLN ?: GrowerGLN,
            // Use growerSFDCId first, then first GrowerGLN from array, then original GrowerGLN
            // reqBuyerSFDCId: growerStatus?.growerSFDCId ?: (growerStatus?.GrowerGLN instanceof List ? growerStatus?.GrowerGLN?.getAt(0) : growerStatus?.GrowerGLN) ?: GrowerGLN,
            
            reqBuyerGLN: growerStatus?.GrowerGLN ?: growerStatus?.ActualGrowerGLN,
            // Priority: growerSFDCId -> GrowerGLN -> first from array
            reqBuyerSFDCId: growerStatus?.growerSFDCId ?: growerStatus?.GrowerGLN,
            
            reqPayerGLN: value.ProductBookingPartners.Payer.PartnerInformation.PartnerIdentifier,
            reqSeedYear: seedYear,
            reqCustOrdNum: reqCustOrdNum,
            reqProdBookType: value.ProductBookingProperties.ProductBookingType,
            reqSynOrdNum: value.ProductBookingProperties.ReferenceInformation.DocumentReference.DocumentIdentifier,
            respExceptions: geterrorGrower(reqCustOrdNum, GrowerGLN) ?: [],
            productItem: []
        ]

        def productBookingDetails = value.ProductBookingDetails
        def productLineItems = productBookingDetails.ProductBookingProductLineItem
        if (!(productLineItems instanceof List)) {
            productLineItems = [productLineItems]
        }

        productLineItems.each { value1 ->
            def GTIN = value1.ProductIdentification.ProductIdentifier
            def productItem = [
                reqProdGTIN: GTIN,
                reqProdQty: value1.ProductQuantity.Measurement.MeasurementValue,
                reqType: value1.ActionRequest,
                reqRDD: value1.RequestedShipDateTime.DateTimeInformation.DateTime,
                reqCustOrdLineNum: value1.ProductBookingOrderLineItemNumber,
                reqSynOrdLineNum: value1.LineNumber,
                reqM2MOrderRef: reqCustOrdNum + "|" + value1.ProductBookingOrderLineItemNumber,
                reqProdQtyDelta: value1.IncreaseOrDecrease.ProductQuantityChange.Measurement.MeasurementValue,
                respExceptions: geterrorProduct(reqCustOrdNum, GrowerGLN, GTIN) ?: []
            ]
            orderDetail.productItem << productItem
        }
        
        result.orderDetail << orderDetail
    }

    message.setProperty("sfRequest", JsonOutput.prettyPrint(JsonOutput.toJson(result)))
  
    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(result)))
    return message
}