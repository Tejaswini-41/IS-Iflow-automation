import java.util.Base64
import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Get the payload from headers
    def headers = message.getHeaders()
    def headerValue1 = headers.get("InputPayload")
    def headerValue2 = headers.get("ResponseLog")

    // Encode the payload to Base64
    def encoded1 = Base64.getEncoder().encodeToString(headerValue1.bytes)
    def encoded2 = Base64.getEncoder().encodeToString(headerValue2.bytes)

    // Set the encoded payload back to the message as properties
    message.setProperty("BinaryInput", encoded1)
    message.setProperty("BinaryResponse", encoded2)
    
    return message
}