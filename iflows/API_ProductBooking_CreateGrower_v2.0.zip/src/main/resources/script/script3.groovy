import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def body = message.getBody(String)
    def jsonSlurper = new JsonSlurper()
    def payload = jsonSlurper.parseText(body)

    def seedYear = ""
    def contactInfo = payload.OrderChange.Header.From.PartnerInformation.ContactInformation.find { it.ContactDescription == "SeedYear" }
    if (contactInfo?.ContactName) {
        seedYear = contactInfo.ContactName
    }

    def shipToList = []
    def orderChangeBodies = payload.OrderChange.OrderChangeBody
    if (!(orderChangeBodies instanceof List)) {
        orderChangeBodies = [orderChangeBodies]
    }

    orderChangeBodies.each { orderChangeBody ->
        def shipToInfo = orderChangeBody?.OrderChangePartners?.ShipTo ?: [:]
        shipToList << shipToInfo
    }
    def outputJson = JsonOutput.toJson(shipToList)
    def partnerIdentifier = payload.OrderChange.Header.From.PartnerInformation.PartnerIdentifier ?: null
    if (partnerIdentifier instanceof List) {
        partnerIdentifier = partnerIdentifier.collect { "'${it}'" }
    } else if (partnerIdentifier) {
        partnerIdentifier = "'${partnerIdentifier}'"
    }

    def resellerGLN = payload.OrderChange.Header.From.PartnerInformation.PartnerIdentifier
    if (resellerGLN instanceof List) {
        resellerGLN = resellerGLN.collect { "'${it}'" }
    } else if (resellerGLN) {
        resellerGLN = "'${resellerGLN}'"
    }

    // Extract ProductIdentifiers
    def productIdentifiers = []
    orderChangeBodies.each { orderChangeBody ->
        def orderChangeDetails = orderChangeBody.OrderChangeDetails
        if (orderChangeDetails instanceof List) {
            orderChangeDetails.each { orderChangeDetail ->
                def productLineItems = orderChangeDetail.OrderChangeProductLineItem
                if (productLineItems instanceof List) {
                    productLineItems.each { productLineItem ->
                        def productIdentifier = productLineItem?.ProductIdentification?.ProductIdentifier
                        if (productIdentifier) {
                            productIdentifiers << productIdentifier
                        }
                    }
                } else if (productLineItems instanceof Map) {
                    def productIdentifier = productLineItems?.ProductIdentification?.ProductIdentifier
                    if (productIdentifier) {
                        productIdentifiers << productIdentifier
                    }
                }
            }
        } else if (orderChangeDetails instanceof Map) {
            def productLineItems = orderChangeDetails.OrderChangeProductLineItem
            if (productLineItems instanceof List) {
                productLineItems.each { productLineItem ->
                    def productIdentifier = productLineItem?.ProductIdentification?.ProductIdentifier
                    if (productIdentifier) {
                        productIdentifiers << productIdentifier
                    }
                }
            } else if (productLineItems instanceof Map) {
                def productIdentifier = productLineItems?.ProductIdentification?.ProductIdentifier
                if (productIdentifier) {
                    productIdentifiers << productIdentifier
                }
            }
        }
    }
    // Remove duplicates
    productIdentifiers = productIdentifiers.unique()
    
    // Map each element to add single quotes
    def quotedProductIdentifiers = productIdentifiers.collect { "'${it}'" }

    // Join the array back into a comma-separated string
    def GTINSeperatedCommas = quotedProductIdentifiers.join(',')

    // Convert the result to JSON
    def productIdentifiersJson = JsonOutput.toJson(productIdentifiers)
    
    // Extract ShipTo.PartnerInformation.PartnerIdentifier with length between 13 and 16
    def shipToPartnerIdentifiers = []
    orderChangeBodies.each { orderChangeBody ->
        def shipToInfo = orderChangeBody?.OrderChangePartners?.ShipTo?.PartnerInformation?.PartnerIdentifier
        if (shipToInfo instanceof List) {
            shipToInfo.each { identifier ->
                if (identifier.length() >= 13 && identifier.length() <= 16) {
                    shipToPartnerIdentifiers << identifier
                }
            }
        } else if (shipToInfo?.length() >= 13 && shipToInfo?.length() <= 16) {
            shipToPartnerIdentifiers << shipToInfo
        }
    }
    // Remove duplicates
    shipToPartnerIdentifiers = shipToPartnerIdentifiers.unique()
    def growerGLNForSFDCQuery = shipToPartnerIdentifiers.unique().collect { "'${it}US03'" }.join(',')
    def growerGLNSeperatedCommas = shipToPartnerIdentifiers.join(',')
    
    def growerGLN = JsonOutput.toJson(shipToPartnerIdentifiers)

    // Remove square brackets from growerGLNSeperatedCommas
    def growerGLNSeperatedCommasNoBrackets = growerGLNSeperatedCommas.replaceAll(/[\[\]]/, '')
    growerGLNSeperatedCommas = growerGLNSeperatedCommas.replaceAll(/[\[\]]/, '')
    
    // Set properties
    message.setProperty("GTIN", productIdentifiersJson)
    message.setProperty("growerGLN", growerGLN)
    message.setProperty("growerGLNSeperatedCommas", growerGLNSeperatedCommas)
    message.setProperty("GTINSeperatedCommas", GTINSeperatedCommas)
    message.setProperty("growerGLNForSFDCQuery", growerGLNForSFDCQuery)
    message.setProperty("growerGLNSeperatedCommasNoBrackets", growerGLNSeperatedCommasNoBrackets)
    
    // Set properties
    message.setProperty("seedYear", seedYear)
    message.setProperty("resellerGLN", resellerGLN)
    message.setProperty("partnerIdentifier", partnerIdentifier)
    message.setProperty("growerAddress", outputJson)
    
    return message
}