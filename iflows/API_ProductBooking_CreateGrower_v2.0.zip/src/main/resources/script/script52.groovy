import com.sap.gateway.ip.core.customdev.util.Message


def Message processData(Message message) {
    // Retrieve headers
    def headers = message.getHeaders()
    def businessProcess = headers.get("businessProcess")
    def inputPayloadXml = headers.get("InputPayload")
    def requiredField = headers.get("RequiredField")
    def partnerIdentifier = headers.get("partnerIdentifier")

    // Parse the XML payload
    def inputPayload = new XmlSlurper().parseText(inputPayloadXml)

    // Determine the message type
    def messageType = ""
    if (businessProcess == "GrowerOrderSummaryWS" || 
        inputPayload?.Envelope?.Body?.ProductBooking?.ProductBookingBody?.ProductBookingProperties?.ProductBookingType?.text() == "SummaryRequest" || 
        businessProcess == "GrowerOrderSummaryWS53") {
        messageType = "| Message Type:SummaryRequest"
    } else if (businessProcess == "OrderResponseLogWS" || 
               businessProcess == "OrderResponseLogWS53" || 
               businessProcess == "ChangeLogWS") {
        messageType = "| Message Type:Order Response Log"
    } else if (businessProcess == "GrowerOrderWS" || 
               businessProcess == "ProductBookingWS" || 
               businessProcess == "ProductBookingWS53") {
        messageType = "| Message Type:Create New Grower"
    }

    // Determine the business process type
    def businessType = ""
    if (businessProcess == "GrowerOrderSummaryWS" || 
        businessProcess == "OrderResponseLogWS" || 
        businessProcess == "ProductBookingWS") {
        businessType = " | BusinessProcess: AgGateway V6.0"
    } else if (businessProcess == "GrowerOrderSummaryWS53" || 
               businessProcess == "OrderResponseLogWS53" || 
               businessProcess == "ProductBookingWS53") {
        businessType = " | BusinessProcess: AgGateway V5.3"
    } else if (inputPayload?.Envelope?.Body?.ProductBooking?.ProductBookingBody?.ProductBookingProperties?.ProductBookingType?.text() == "SummaryRequest" || 
               businessProcess == "ChangeLogWS" || 
               businessProcess == "GrowerOrderWS") {
        businessType = " | BusinessProcess: Agvance"
    } else {
        businessType = businessProcess ?: ""
    }

    // Construct the final output
    def finalOutput = requiredField + messageType + businessType
    if (partnerIdentifier != null) {
        finalOutput += " | From PartnerIdentifier: " + partnerIdentifier
    }

    // Print the final output
    println finalOutput

    // Set the final output as a property named 'finalOutput'
    message.setProperty("business", businessType)
    message.setProperty("source", messageType)
    message.setProperty("RequiredFiled", finalOutput)
    
    return message
}