import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
    def body = message.getBody(String)
    // Remove XML declaration
    body = body.replaceAll(/<\?xml.*?\?>\s*/, '').trim()
    message.setBody(body)
    return message
}