import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def processData(Message message) {
    // JSON body to be stored as a property
    def jsonBody = '''
    {
        "EC002": "Blank Purchase Order Number-Purchase Order Number Must Be Present For Order Management",
        "EC005": "Request Type Is Not Allowed-Request Type Must Be New, Changed, Cancelled Or SummaryRequest",
        "EC006": "Order Type Code For Request Is Not Allowed-Syngenta Seeds Only Allows Order Type Code NE or KN For Grower Order Processing",
        "EC009": "Unacceptable Requested Ship Date-The Requested Ship Date Is Not Correctly Formatted Or Is Outside Of The Date Range Defined As Acceptable For The Current Or Previous Seed Year",
        "EC015": "No Match On Buyer Partner Identifier-Buyer Partner Identifier Is Not Correctly Formatted Or Does Not Match Any Syngenta Seeds Partner Identifier",
        "EC027": "Missing Purchase Order Line Number-Purchase Order Line Number Must Be Present For Order Management",
        "EC028": "Invalid Product Identifier for Ship To-Product Not Available In Ship To Product Catalog Or Ship To Requires A Contract To Purchase Product",
        "EC030": "Invalid Product Identifier-Product Identifier Is Not Correctly Formatted Or Does Not Match Any Syngenta Seeds Product Identifier",
        "EC032": "Invalid Unit Of Measure-Unit Of Measure Is Not Valid For Product",
        "EC039": "Unacceptable Document Date-Document Date Is Not Correctly Formatted Or Is Outside Of The Date Range Defined As Acceptable For The Current Or Previous Seed Year",
        "EC041": "Unacceptable Purchase Order Issue Date-Purchase Order Issue Date Is Not Correctly Formatted Or Is Outside Of The Date Range Defined As Acceptable For The Current Or Previous Seed Year",
        "EC053": "Ship To Partner Identifier Is Invalid-Ship To Partner Identifier Is Not Correctly Formatted",
        "EC065": "Purchase Order Number Not Specified-Purchase Order Number Must Be Present For Order Management",
        "EC098": "Order Accepted Conditionally-Order Request Successfully Processed By Syngenta Seeds But Ship To Stewardship Agreement Is Required",
        "EC100": "Seed Year Not Allowed For Processing-Order Management Can Only Be Performed For The Current Seed Year",
        "EC102": "Action Request Not Valid For Order Management-Action Request Must Be Add, Change, Replace Or Delete For Order Management",
        "EC109": "Invalid Product Quantity For Order Line Addition-Product Quantity Must Be Greater Than Zero For Addition Of New Order Line"
    }
    '''

    // Parse the JSON body
    def jsonSlurper = new JsonSlurper()
    def jsonObject = jsonSlurper.parseText(jsonBody)

      // Store the JSON object in a property as a JSON string
    message.setProperty("ErrorCodes", JsonOutput.toJson(jsonObject))

    // // Optionally, set the JSON as the message body
    // message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(jsonObject)))

    return message
}