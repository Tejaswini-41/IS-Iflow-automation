import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def jsonSlurper = new JsonSlurper()
    def payload = jsonSlurper.parseText(body)

    def responseStatus = ""
    def contactInfo = payload.OrderChange.Header.From.PartnerInformation.ContactInformation.find { it.ContactDescription == "SeedYear" }
    if (contactInfo?.ContactName) {
        responseStatus = contactInfo.ContactName
    }

    def result = [
        ResponseStatus__c: responseStatus,
        ResellerName__c: payload.OrderChange.Header.From.PartnerInformation.PartnerName,
        ResellerGLN__c: payload.OrderChange.Header.From.PartnerInformation.PartnerIdentifier,
        GrowerName__c: payload.OrderChange.OrderChangeBody.OrderChangePartners.ShipTo.PartnerInformation.PartnerName,
        GrowerGLN__c: payload.OrderChange.OrderChangeBody.OrderChangePartners.ShipTo.PartnerInformation.PartnerIdentifier,
        Type__c: "M2MLog",
        Status__c: "",
        CustomerSalesOrderNum__c: payload.OrderChange.OrderChangeBody.OrderChangeProperties.PurchaseOrderNumber.DocumentIdentifier,
        SyngentaSalesOrderNum__c: ""
    ]

    message.setProperty("M2MInput", JsonOutput.toJson(result))
    return message
}