import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    // Retrieve properties
    def partnerIdentifier = message.getProperty("partnerIdentifier")
    def resellerGLN = message.getProperty("resellerGLN")
    def growerAddress = message.getProperty("growerAddress")
    def growerGLN = message.getProperty("growerGLN")
    def gtin = message.getProperty("GTIN")

    // Initialize lists
    def growerAddressList = []
    def growerGLNList = []
    def gtinList = []

    // Convert growerAddress, growerGLN, and GTIN to lists if they are JSON strings
    def jsonSlurper = new JsonSlurper()
    if (growerAddress?.startsWith('[') && growerAddress?.endsWith(']')) {
        growerAddressList = jsonSlurper.parseText(growerAddress)
    }
    if (growerGLN?.startsWith('[') && growerGLN?.endsWith(']')) {
        growerGLNList = jsonSlurper.parseText(growerGLN)
    }
    if (gtin?.startsWith('[') && gtin?.endsWith(']')) {
        gtinList = jsonSlurper.parseText(gtin)
    }

    // Check conditions
    def conditionMet = partnerIdentifier != null && partnerIdentifier != "" &&
                       resellerGLN != null && resellerGLN != "" &&
                       growerAddressList instanceof List && growerAddressList.size() > 0 &&
                       growerGLNList instanceof List && growerGLNList.size() > 0 &&
                       gtinList instanceof List && gtinList.size() > 0

    // Set the result in the message body or properties as needed
    message.setProperty("conditionMet", conditionMet)
    return message
}