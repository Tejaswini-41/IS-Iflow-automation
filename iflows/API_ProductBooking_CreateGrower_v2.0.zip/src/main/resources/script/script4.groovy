import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import com.sap.gateway.ip.core.customdev.util.Message

// Message processing
def Message processData(Message message) {
    // Retrieve the year to check from message properties
    def yearToCheck = message.getProperty("seedYear") as Integer

    // Get the current date
    def currentDate = new Date()

    // Define the fiscal start date format
    def formatter = new SimpleDateFormat("MM/dd/yyyy")

    // Get the current year
    def calendar = Calendar.getInstance()
    calendar.setTime(currentDate)
    def currentYear = calendar.get(Calendar.YEAR)

    // Determine the fiscal start date
    def fiscalStartDateValue = "10/01/$currentYear"
    def fiscalStartDate = formatter.parse(fiscalStartDateValue)

    // Calculate the fiscal year
    def fiscalYear
    if (currentDate.after(fiscalStartDate)) {
        fiscalYear = currentYear + 1
    } else {
        fiscalYear = currentYear
    }

    // Check if the year to check is valid
    def isValid = (yearToCheck == fiscalYear || yearToCheck == fiscalYear - 1 || yearToCheck == fiscalYear + 1)

    // Set the result as a message property
    message.setProperty("isValidMarketYear", isValid)

    return message
}