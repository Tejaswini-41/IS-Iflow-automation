import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

def Message processData(Message message) {
    def inputPayload = message.getProperty("InputPayload")
    def parsedPayload = new XmlSlurper().parseText(inputPayload)
    
    def currDateTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'"))
    def identifier = currDateTime.replace("-", "").replace(":", "")
    
    def writer = new StringWriter()
    def xml = new MarkupBuilder(writer)
    
    xml.'urn:OrderResponse'('xmlns:urn': 'urn:cidx:names:specification:ces:schema:all:5.0') {
        'urn:Header' {
            'urn:ThisDocumentIdentifier' {
                'urn:DocumentIdentifier'(parsedPayloa.Body.inboundData.xmlPayload.OrderChange.Header.ThisDocumentIdentifier.DocumentIdentifier.text())
            }
            'urn:ThisDocumentDateTime' {
                'urn:DateTime'('DateTimeQualifier': 'On', currDateTime)
            }
            'urn:From'(parsedPayload.Body.inboundData.xmlPayload.OrderChange.Header.To.text())
            'urn:To'(parsedPayload.Body.inboundData.xmlPayload.OrderChange.Header.From.text())
        }
        parsedPayload.Body.inboundData.xmlPayload.OrderChange.OrderChangeBody.each { value ->
            'urn:OrderResponseBody' {
                'urn:OrderResponseProperties'(value.OrderChangeProperties ?: [:])
                'urn:ResponseStatus' {
                    'urn:ResponseStatusReasonIdentifier'('Agency': 'ECMS', 'E')
                    'urn:ResponseStatusReasonDescription'(message.getProperty('InvalidYear'))
                }
                'urn:OrderResponsePartners'(value.OrderChangePartners)
                'urn:OrderResponseDetails' {
                    'urn:OrderResponseProductLineItem'(value.OrderChangeDetails.OrderChangeProductLineItem)
                }
            }
        }
    }
    
    message.setBody(writer.toString())
    return message
}