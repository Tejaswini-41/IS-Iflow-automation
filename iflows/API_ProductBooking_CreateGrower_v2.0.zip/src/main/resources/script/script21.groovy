import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Parse the incoming body and property
    def validateGLN = new JsonSlurper().parseText(message.getBody(String))
    def growerAddress = new JsonSlurper().parseText(message.getProperty("growerAddress"))
    def resellerGLN = message.getProperty("resellerGLN")?.replaceAll("'", "") 
    def stateCodeString = message.getProperty("stateCode")
    def stateCode = new JsonSlurper().parseText(stateCodeString) // Parse the stateCode string into a map

    // Function to get AGIIS GLN details
    def getAgiisGLN = { gln ->
        validateGLN.find { it.GLN == gln }
    }

    // Ensure growerAddress is a list
    def growerAddressList = growerAddress instanceof List ? growerAddress : [growerAddress]

    // Process the growerAddress
    def growers = growerAddressList.collect { partnerInfo ->
        def partner = partnerInfo.PartnerInformation
        def partnerIdentifiers = partner.PartnerIdentifier instanceof List ? partner.PartnerIdentifier : [partner.PartnerIdentifier]
        def validIdentifier = partnerIdentifiers.find { it.length() >= 13 && it.length() <= 16 }
        def agiisGLN = getAgiisGLN(validIdentifier)
        
        // Debugging output
        println "Partner Identifier: ${validIdentifier}"
        println "AGIIS GLN: ${agiisGLN}"

        [
            "reqDocIdentifier": "",
            "gln": validIdentifier,
            "propId": agiisGLN?.propId ?: "",
            "sfdcid": "",
            "agiisStatus": agiisGLN?.exists ? agiisGLN.active : "Invalid",
            "name": agiisGLN?.growerName ?: "",
            "fn": agiisGLN?.growerFirstName ?: "",
            "ln": agiisGLN?.growerLastName ?: "",
            "mailLine": agiisGLN?.growerMailAddrLine ?: "",
            "mailCity": agiisGLN?.growerMailCity ?: "",
            "mailSt": stateCode[agiisGLN?.growerMailState] ?: agiisGLN?.growerMailState ?: "",
            "mailPostCode": agiisGLN?.growerMailPostalCode ?: "",
            "mailCtry": agiisGLN?.growerMailCountry ?: "",
            "shipLine": agiisGLN?.growerShipAddrLine ?: "",
            "shipCity": agiisGLN?.growerShipCity ?: "",
            "shipSt": stateCode[agiisGLN?.growerShipState] ?: agiisGLN?.growerShipState ?: "",
            "shipPostCode": agiisGLN?.growerShipPostalCode ?: "",
            "shipCtry": agiisGLN?.growerShipCountry ?: "",
            "isPerson": agiisGLN?.isPerson ?: false
        ]
    }

    // Create the final output
    def result = [
        "resellerGLN": resellerGLN,
        "growers": growers
    ]

    // Convert the result to JSON and set it as the message body
    def jsonResult = JsonOutput.prettyPrint(JsonOutput.toJson(result))
    message.setBody(jsonResult)
    
    return message
}