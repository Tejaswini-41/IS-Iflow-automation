import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def properties = message.getProperties()
    
    // Parse the sfrequest property
    def sfrequest = new JsonSlurper().parseText(properties.get("sfRequest"))

    // Initialize the result
    def result = [
        newGrowers: sfrequest.newGrowers,
        orderDetail: sfrequest.orderDetail.collect { order ->
            def combinedRespExceptions = (order.respExceptions + order.productItem.collect { it.respExceptions }.flatten()).unique()
            order.remove('respExceptions')
            order + [respExceptions: combinedRespExceptions]
        }
    ]

    // Set the formatted JSON as a property
    message.setProperty("sfRequest",JsonOutput.prettyPrint(JsonOutput.toJson(result)))
    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(result)))
    return message
}