import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Retrieve the sfresponse property
    def sfresponse = message.getProperty("sfresponse")
    
    // Check if sfresponse is null or empty
    // if (sfresponse == null || sfresponse.isEmpty()) {
    //     throw new IllegalArgumentException("sfresponse must not be null or empty")
    // }
    
    // Parse the JSON string into a Groovy object
    def jsonSlurper = new JsonSlurper()
    def response = jsonSlurper.parseText(sfresponse)
    
    // Helper function to format numbers
    def formatNumber = { number ->
        if (number instanceof Number) {
            return String.format("%.3f", number.doubleValue())
        }
        return null
    }
    
    // Process the data
    def result = response.collectMany { value ->
        value.productItem.collect { item ->
            [
                reqCustOrdNum: value.reqCustOrdNum ?: "",
                reqCustOrdLineNum: item.reqCustOrdLineNum ?: "",
                reqSynOrdNum: value.reqSynOrdNum ?: "",
                reqSynOrdLineNum: item.reqSynOrdLineNum ?: "",
                reqProdGTIN: item.reqProdGTIN ?: "",
                reqProdQty: formatNumber(item.reqProdQty),
                reqRDD: item.reqRDD ?: "",
                respAvailProdQty: formatNumber(item.respAvailProdQty),
                respExceptions: value.respExceptions instanceof List ? value.respExceptions : [],
                respExceptionsLine: item.respExceptions ?: "",
                reqProdQtyDelta: formatNumber(item.reqProdQtyDelta),
                respAvailStatus: item.respAvailStatus ?: "",
                respLongShortQty: item.respLongShortQty,
                reqM2MOrderRef: item.reqM2MOrderRef ?: "",
                respSpcInstr: value.respSpcInstr ?: "",
                respProdName: item.respProdName ?: "Not Available",
                reqProdBookType: item.reqProdBookType ?: "",
                respPOQty: (item.respPOQty == null && item.respBOQty == null) ? null : 
                           formatNumber((item.respPOQty?.abs()?.toDouble() ?: 0.0) + (item.respBOQty?.abs()?.toDouble() ?: 0.0)),
                respTotalPOQty: (item.respTotalPOQty == null && item.respTotalBOQty == null) ? null : 
                                formatNumber((item.respTotalPOQty?.toDouble() ?: 0.0) + (item.respTotalBOQty?.toDouble() ?: 0.0)),
                respTotalGrowerQty: item.respTotalGrowerQty!=null? String.format("%.3f", item.respTotalGrowerQty.toDouble()) : null
            ]
        }
    }
    
   // Wrap the result in a root element for proper XML conversion
    def wrappedResult = [response: result]
    
    // Convert the result back to JSON with pretty print
    def jsonOutput = JsonOutput.prettyPrint(JsonOutput.toJson(wrappedResult))
    message.setBody(jsonOutput)
    
    return message
}