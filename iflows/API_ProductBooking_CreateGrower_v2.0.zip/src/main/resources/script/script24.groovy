import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Parse the incoming body and property
    def payload = new JsonSlurper().parseText(message.getBody(String))
    def setErrorList = new JsonSlurper().parseText(message.getProperty("setErrorList"))

    // Function to add grower details
    def addGrower = { grower ->
        def growerDetails = payload.find { it.grower == grower }
        growerDetails?.respException
    }

    // Map order details
    def orderDetail = setErrorList.orderDetail.collect { item ->
        def headerError = item.HeaderError
        if (payload.any { it.grower == item.GrowerGLN } && addGrower(item.GrowerGLN) != null) {
            headerError = item.HeaderError + addGrower(item.GrowerGLN)
        }
        [
            "reqCustOrdNum": item.reqCustOrdNum,
            "GrowerGLN": item.GrowerGLN,
            "ActualGrowerGLN":item.ActualGrowerGLN,
            "reqDocIdentifier": item.reqDocIdentifier,
            "growerSFDCId": item.growerSFDCId,
            "growerSFDCStatus": item.growerSFDCStatus,
            "HeaderError": headerError,
            "productItem": item.productItem
        ]
    }

    // Create the final output
    def result = [
        "resellerGLN": setErrorList.resellerGLN,
        "growers": setErrorList.growers,
        "orderDetail": orderDetail
    ]

    // Convert the result to JSON and set it as the message body
    def jsonResult = JsonOutput.prettyPrint(JsonOutput.toJson(result))
    // message.setBody(jsonResult)
    message.setProperty("setErrorList",jsonResult)
    
    return message
}