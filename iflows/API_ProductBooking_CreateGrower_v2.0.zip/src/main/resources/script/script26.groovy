import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Get the payload as a string
    def body = message.getBody(String)
    
    // Parse the JSON payload
    def jsonSlurper = new JsonSlurper()
    def payload = jsonSlurper.parseText(body)
    
    // Initialize the result
    def result = "false"
    
    // Check if the third composite response has a successful HTTP status code and a non-null, positive totalSize
    if (payload?.result?.compositeResponse?.get(2)?.httpStatusCode == "200" && 
        payload?.result?.compositeResponse?.get(2)?.body?.totalSize?.toInteger() > 0) {
        
        def record = payload.result.compositeResponse[2].body.records
        if (!(record instanceof List)) {
            record = [record]
        }
        
        // Check nested conditions
        def conditions = [
            record*.giic_SalesOrderEditAccess__c,
            record*.giic_showGrowerOrders__c,
            record*.giic_Sales_Order_Creation_Updation__c
        ].flatten()
        
        if (conditions.any { it == null || !it.contains("US NK") }) {
            result = "Seed Year Not Allowed For Order Management"
        } else {
            result = "true"
        }
    }
    
    // Extract EAN_GTIN__c values
    def eanGtinList = []
    if (payload?.result?.compositeResponse?.get(0)?.httpStatusCode == "200" && 
        payload?.result?.compositeResponse?.get(0)?.body?.totalSize?.toInteger() > 0) {
        
        def records = payload.result.compositeResponse[0].body.records
        if (!(records instanceof List)) {
            records = [records]
        }
        eanGtinList = records.collect { it?.EAN_GTIN__c } ?: []
    }
    
    // Store the results as properties
    message.setProperty("product_Gtins", JsonOutput.toJson(eanGtinList))
    message.setProperty("query8", result)
    
    // Parse PMRXRef_GTINs property from JSON string
    def PMRXRef_GTINs = jsonSlurper.parseText(message.getProperty("PMRXRef_GTINs"))
    
    // DataWeave script to process records
    def processedRecords = payload.result.compositeResponse[0].body.records
    if (!(processedRecords instanceof List)) {
        processedRecords = [processedRecords]
    }
    processedRecords = processedRecords.collect { record ->
        def originalGtin = PMRXRef_GTINs.find { it.giic_Material_Number__r?.gii__ProductReference__c == record.Id }?.giic_GTIN_Number__c ?: null
        [
            "OriginalGTIN": originalGtin,
            "GTIN": record?.EAN_GTIN__c,
            "Brands": record?.Brand_US__c,
            "enogenDealer": payload.result.compositeResponse[1].body.records?.Enogen_Dealer__c?.toLowerCase() ?: ""
        ]
    }
    
    // Store the processed records as a property
    message.setProperty("CheckEG", JsonOutput.toJson(processedRecords))
    def isProductGtinsNotEmpty = eanGtinList.size() > 0
    message.setProperty("isProductGtinsNotEmpty", isProductGtinsNotEmpty)
    
    return message
}