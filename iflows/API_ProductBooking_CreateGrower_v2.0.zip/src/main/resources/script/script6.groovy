import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.MarkupBuilder
import groovy.xml.XmlUtil

def Message processData(Message message) {
    // Get the properties
    def businessProcess = message.getProperty("businessProcess")
    def inputPayload = message.getProperty("InputPayload")
    
    // Parse the input XML payload
    def xml = new XmlSlurper().parseText(inputPayload)
    
    // Determine the namespace based on the business process
    def urn
    if (businessProcess == "ProductBookingWS") {
        urn = [uri: "urn:cidx:names:specification:ces:schema:all:6.0", prefix: "cidx5_3"]
    } else if (businessProcess == "ProductBookingWS54") {
        urn = [uri: "urn:cidx:names:specification:ces:schema:all:5.4.0", prefix: "cidx5_3"]
    } else {
        urn = [uri: "urn:cidx:names:specification:ces:schema:all:5:3", prefix: "cidx5_3"]
    }
    
    // Get the current date and time
    def currDateTime = new Date().format("yyyy-MM-dd'T'HH:mm:ss'Z'")
    
    // Extract necessary values from the input XML
    def documentIdentifier = xml.Body.inboundData.xmlPayload.ProductBooking.Header.ThisDocumentIdentifier.DocumentIdentifier.text()
    def from = xml.Body.inboundData.xmlPayload.ProductBooking.Header.To.text()
    def to = xml.Body.inboundData.xmlPayload.ProductBooking.Header.From.text()
    def requiredField = message.getProperty("requiredField")
    
    // Create the response XML
    def writer = new StringWriter()
    def xmlBuilder = new MarkupBuilder(writer)
    xmlBuilder."${urn.prefix}:ProductBookingResponse"('xmlns:cidx5_3': urn.uri) {
        "${urn.prefix}:Header" {
            "${urn.prefix}:ThisDocumentIdentifier" {
                "${urn.prefix}:DocumentIdentifier"(documentIdentifier)
            }
            "${urn.prefix}:ThisDocumentDateTime" {
                "${urn.prefix}:DateTime"('DateTimeQualifier': "On", currDateTime)
            }
            "${urn.prefix}:From"(from)
            "${urn.prefix}:To"(to)
        }
        xml.Body.inboundData.xmlPayload.ProductBooking.ProductBookingBody.each { body ->
            "${urn.prefix}:ProductBookingResponseBody" {
                "${urn.prefix}:ProductBookingResponseProperties" {
                    body.ProductBookingProperties.each { prop ->
                        "${urn.prefix}:${prop.name()}"(prop.text())
                    }
                    "${urn.prefix}:ResponseStatus" {
                        "${urn.prefix}:ResponseStatusReasonIdentifier"('Agency': "SUPPLIER", "E")
                        "${urn.prefix}:ResponseStatusReasonDescription"(requiredField)
                    }
                }
                "${urn.prefix}:ProductBookingResponsePartners" {
                    body.ProductBookingPartners.each { partner ->
                        "${urn.prefix}:${partner.name()}"(partner.text())
                    }
                }
                "${urn.prefix}:ProductBookingResponseDetails" {
                    body.ProductBookingDetails.ProductBookingProductLineItem.each { item ->
                        "${urn.prefix}:ProductBookingResponseProductLineItem" {
                            item.children().each { child ->
                                "${urn.prefix}:${child.name()}"(child.text())
                            }
                        }
                    }
                }
            }
        }
    }
    
    // Set the response XML as the message body
    message.setBody(writer.toString())
    message.setHeader("Content-Type", "application/xml")
    
    return message
}