/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;

import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
 def payload = new JsonSlurper().parseText(message.getBody(String))

   // Get properties
def setErrorListJson = message.getProperty("setErrorList")
def checkEGJson = message.getProperty("CheckEG")
def gtinStatusJson = message.getProperty("GtinStatus")

def setErrorList = setErrorListJson ? new JsonSlurper().parseText(setErrorListJson) : [:]
def checkEG = checkEGJson ? new JsonSlurper().parseText(checkEGJson) : []
def gtinStatus = gtinStatusJson ? new JsonSlurper().parseText(gtinStatusJson) : []

// Functions equivalent to DWL functions
def addcheckEG = { gtin ->
    checkEG.findAll { it.status == false }
}

def addGtinStatus = { gtin ->
    gtinStatus.findAll { it.status == false }.collect { it.GTIN }
}

// Build the result payload
def result = [
    resellerGLN: setErrorList.resellerGLN,
    growers: setErrorList.growers,
    orderDetail: setErrorList.orderDetail?.collect { item ->
        [
            reqCustOrdNum: item.reqCustOrdNum,
            GrowerGLN: item.GrowerGLN,
            ActualGrowerGLN: item.ActualGrowerGLN,
            reqDocIdentifier: item.reqDocIdentifier,
            growerSFDCId: item.growerSFDCId,
            growerSFDCStatus: item.growerSFDCStatus,
            HeaderError: item.HeaderError,
            productItem: item.productItem
        ]
    } ?: []
]

// Convert to JSON and set as payload
def jsonPayload = JsonOutput.prettyPrint(JsonOutput.toJson(result))
    message.setProperty("setErrorList", jsonPayload)
    return message;
}