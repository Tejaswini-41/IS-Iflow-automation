import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def payload = new JsonSlurper().parseText(body)
    def properties = message.getProperties()
    def businessProcess = properties.get("businessProcess")
    
    def compositeResponse0 = payload.result.compositeResponse[0]
    def httpStatusCode0 = compositeResponse0.httpStatusCode
    def totalSize0 = compositeResponse0.body.totalSize

    def query1 = httpStatusCode0 == "200" && totalSize0 != null && totalSize0 == "1" ? "true" : "false"
    message.setProperty("query1", query1)
    // println "Query1: ${query1}, httpStatusCode0: ${httpStatusCode0}, totalSize0: ${totalSize0}"

    def compositeResponse1 = payload.result.compositeResponse[1]
    def httpStatusCode1 = compositeResponse1.httpStatusCode
    def totalSize1 = compositeResponse1.body.totalSize

    def query2 = httpStatusCode1 == "200" && totalSize1 != null && totalSize1.toInteger() > 0 ? "true" : "false"
    message.setProperty("query2", query2)
    // println "Query2: ${query2}, httpStatusCode1: ${httpStatusCode1}, totalSize1: ${totalSize1}"

    def compositeResponse2 = payload.result.compositeResponse[2]
    println "CompositeResponse2: ${compositeResponse2}"
    def records2 = compositeResponse2.body.records
    def record2 = records2 instanceof List ? records2.getAt(0) : records2  // Safely access the first record if it exists

    def recordType2 = record2?.attributes?.type
    def referenceId2 = compositeResponse2.referenceId

    def condition1 = recordType2 == "M2MRequestMap__c" && record2?.allowPrdBook__c == "true" && referenceId2 == "m2mMap" && !(businessProcess in ["ChangeLogWS", "OrderResponseLogWS53", "OrderResponseLogWS"])
    def condition2 = recordType2 == "M2MRequestMap__c" && record2?.allowOrdSumLog__c == "true" && referenceId2 == "m2mMap" && (businessProcess in ["ChangeLogWS", "OrderResponseLogWS53", "OrderResponseLogWS"])

    def query3 = condition1 || condition2 ? "true" : "false"
    message.setProperty("query3", query3)
    // println "Query3: ${query3}, recordType2: ${recordType2}, allowPrdBook__c: ${record2?.allowPrdBook__c}, allowOrdSumLog__c: ${record2?.allowOrdSumLog__c}, referenceId2: ${referenceId2}, businessProcess: ${businessProcess}, condition1: ${condition1}, condition2: ${condition2}"

    def compositeResponse3 = payload.result.compositeResponse[3]
    def httpStatusCode3 = compositeResponse3.httpStatusCode
    def totalSize3 = compositeResponse3.body.totalSize

    def query4 = httpStatusCode3 == "200" && totalSize3 != null && totalSize3.toInteger() > 0 ? "true" : "false"
    message.setProperty("query4", query4)
    // println "Query4: ${query4}, httpStatusCode3: ${httpStatusCode3}, totalSize3: ${totalSize3}"

    return message
}