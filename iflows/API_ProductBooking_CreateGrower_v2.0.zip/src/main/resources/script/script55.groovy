import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def payload = new JsonSlurper().parseText(body)
    def output = []

    // Helper functions
    def getCurrentYear = {
        def currentMonth = new Date().format("MM")
        def currentYear = new Date().format("yyyy").toInteger()
        if (["10", "11", "12"].contains(currentMonth)) {
            return (currentYear + 1).toString()
        }
        return currentYear.toString()
    }

    def checkYear = { DateYear, DateMonth ->
        def currentYear = getCurrentYear().toInteger()
        if (["10", "11", "12"].contains(DateMonth) && 
            ((DateYear.toInteger() + 1 == currentYear) || 
             (DateYear.toInteger() + 1 == currentYear - 1) || 
             (DateYear.toInteger() + 1 == currentYear + 1))) {
            return "Success"
        }
        if (["01", "02", "03", "04", "05", "06", "07", "08", "09"].contains(DateMonth) && 
            ((DateYear.toInteger() == currentYear) || 
             (DateYear.toInteger() == currentYear - 1) || 
             (DateYear.toInteger() == currentYear + 1))) {
            return "Success"
        }
        return "Failed"
    }

    def isValidMarketYear = { yearToCheck ->
        def currentDate = new Date()
        def formatter = new SimpleDateFormat("MM/dd/yyyy")
        def calendar = Calendar.getInstance()
        calendar.setTime(currentDate)
        def currentYear = calendar.get(Calendar.YEAR)
        def fiscalStartDateValue = "10/01/$currentYear"
        def fiscalStartDate = formatter.parse(fiscalStartDateValue)
        def fiscalYear = currentDate.after(fiscalStartDate) ? currentYear + 1 : currentYear
        return (yearToCheck == fiscalYear || yearToCheck == fiscalYear - 1 || yearToCheck == fiscalYear + 1)
    }

    // Process ProductBooking
    def productBookingBodies = payload.ProductBooking?.ProductBookingBody
    if (!(productBookingBodies instanceof List)) {
        productBookingBodies = [productBookingBodies]
    }

    productBookingBodies.each { productBookingBody ->
        def productBookingProperties = productBookingBody?.ProductBookingProperties
        def productBookingPartners = productBookingBody?.ProductBookingPartners
        def productBookingDetails = productBookingBody?.ProductBookingDetails

        def result = [
            reqCustOrdNum: productBookingProperties?.ProductBookingOrderNumber ?: "EC002",
            GrowerGLN: productBookingPartners?.ShipTo?.PartnerInformation?.PartnerIdentifier,
            EC005: (["New", "Changed", "Cancelled", "Summary Request"].contains(productBookingProperties?.ProductBookingType)) ? productBookingProperties?.ProductBookingType : "EC005",
            EC006: (["NE", "KN"].contains(productBookingProperties?.ProductBookingOrderTypeCode)) ? "Success" : "EC006",
            EC041: (checkYear((productBookingProperties?.ProductBookingOrderIssuedDate?.DateTime?.split("-")[0]), 
                              (productBookingProperties?.ProductBookingOrderIssuedDate?.DateTime?.split("-")[1])) == "Success") ? "Success" : "EC041",
            // EC053: (productBookingPartners?.ShipTo?.PartnerInformation?.PartnerIdentifier?.size() == 13 || productBookingPartners?.ShipTo?.PartnerInformation?.PartnerIdentifier?.size() == 12) ? "Success" : "EC053",
            // ask about this and take confirmation
               EC053: (productBookingPartners?.ShipTo?.PartnerInformation?.PartnerIdentifier?.size() == 13 || productBookingPartners?.ShipTo?.PartnerInformation?.PartnerIdentifier?.size() == 12) ? "Success" : "EC053",

            EC100: (isValidMarketYear(productBookingProperties?.ProductYear?.toInteger())) ? "Success" : "EC100",
            EC065: (!["", "9999999999", "0000000000"].contains(productBookingProperties?.ProductBookingOrderNumber)) ? "Success" : "EC065",
            productItem: productBookingDetails?.ProductBookingProductLineItem ? [productBookingDetails?.ProductBookingProductLineItem].flatten().collect { item ->
                [
                    GTIN: item?.ProductIdentification?.ProductIdentifier,
                    reqCustOrdLineNum: item?.ProductBookingOrderLineItemNumber ?: "EC027",
                    EC009: (checkYear((item?.RequestedShipDateTime?.DateTimeInformation?.DateTime?.split("-")[0]), 
                                      (item?.RequestedShipDateTime?.DateTimeInformation?.DateTime?.split("-")[1])) == "Success") ? "Success" : "EC009",
                    EC027: (!["", "000000", "999999"].contains(item?.ProductBookingOrderLineItemNumber)) ? "Success" : "EC027",
                    EC032: (item?.ProductQuantity?.Measurement?.UnitOfMeasureCode == "BG") ? "Success" : "EC032",
                    EC102: (["Add", "Change", "Delete"].contains(item?.ActionRequest)) ? "Success" : "EC102",
                    EC109: (item?.ActionRequest?.toLowerCase() == "add" && item?.ProductQuantity?.Measurement?.MeasurementValue.toDouble() <= 0) ? "EC109" : "Success"
                ]
            } : []
        ]
        output << result
    }

    // Set the message body
    def outputJson = JsonOutput.prettyPrint(JsonOutput.toJson(output))
    // message.setBody(outputJson)

    // Set the output as a property
    message.setProperty("checkError", outputJson)
    return message
}