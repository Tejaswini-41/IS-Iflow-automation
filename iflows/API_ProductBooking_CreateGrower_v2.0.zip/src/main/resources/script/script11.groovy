import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def processData(Message message) {
    def jsonSlurper = new JsonSlurper()

    // Parse the properties
    def checkError = message.getProperty("checkError")
    if (checkError instanceof String) {
        checkError = jsonSlurper.parseText(checkError)
    }

    def errorCodes = message.getProperty("ErrorCodes")
    if (errorCodes instanceof String) {
        errorCodes = jsonSlurper.parseText(errorCodes)
    }

    // Helper function to extract error details
    def getErrorDetails = { errorCode, errorKey ->
        if (errorCode?.startsWith("EC")) {
            def errorDescription = errorCodes[errorKey]
            [
                id: errorKey.replace("EC", ""),
                description: errorDescription.split("-")[0],
                comments: errorDescription.split("-")[1]
            ]
        } else {
            null
        }
    }

    // Process the checkError data
    def output = checkError.collect { d1 ->
        def headerErrors = [
            getErrorDetails(d1.EC006, "EC006"),
            getErrorDetails(d1.EC041, "EC041"),
            getErrorDetails(d1.EC053, "EC053"),
            getErrorDetails(d1.EC100, "EC100"),
            getErrorDetails(d1.EC065, "EC065")
        ].findAll { it != null }

        def productItems = d1.productItem.collect { d2 ->
            def lineErrors = [
                getErrorDetails(d2.EC027, "EC027"),
                getErrorDetails(d2.EC032, "EC032"),
                getErrorDetails(d2.EC102, "EC102"),
                getErrorDetails(d2.EC109, "EC109")
            ].findAll { it != null }

            [
                GTIN: d2.GTIN,
                reqCustOrdLineNum: d2.reqCustOrdLineNum,
                LineError: lineErrors
            ]
        }

        [
            reqCustOrdNum: d1.reqCustOrdNum,
            GrowerGLN: d1.GrowerGLN,
            HeaderError: headerErrors,
            productItem: productItems
        ]
    }

    // Set the output as the message body
    def outputJson = JsonOutput.prettyPrint(JsonOutput.toJson(output))
    // message.setBody(outputJson)

    // Set the output as a property
    message.setProperty("setErrorList", outputJson)

    return message
}