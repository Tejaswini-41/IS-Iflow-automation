/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonSlurper
import groovy.json.JsonOutput 
import groovy.json.JsonSlurper
 
def Message processData(Message message) {

def payload = new JsonSlurper().parseText(message.getBody(String))
def growerGLN = new JsonSlurper().parseText(message.getProperty("growerGLN") ?: "[]")
def growerAddress = new JsonSlurper().parseText(message.getProperty("growerAddress") ?: "[]")

def stewardshipEnabled = payload.result?.compositeResponse[1]?.body?.records[0]?.StewarshipEnabled__c
def totalSize = payload.result?.compositeResponse[2]?.body?.totalSize ?: 0
// def stewardshipRecords = payload.result?.compositeResponse[2]?.body?.records ?: []

   def stewardshipRecordObj = payload.result?.compositeResponse[2]?.body?.records ?: []
        // def totalSizeStr = payload.result?.compositeResponse[2]?.body?.totalSize
        // def totalSize = totalSizeStr ? Integer.parseInt(totalSizeStr.toString()) : 0
        // messageLog.addCustomHeaderProperty("TotalSize", totalSize.toString())
        // Convert single record object to list for uniform processing
        def stewardshipRecords = []
        if (stewardshipRecordObj && stewardshipRecordObj instanceof Map) {
            stewardshipRecords << stewardshipRecordObj
        }
    
    
    
def findgln = { gln -> stewardshipRecords.find { it.Stewardship__c == gln }?.GLN__c ?: gln }

// def stewardshipList = stewardshipRecords*.Stewardship__c
def stewardshipList = stewardshipRecords.collect { it.Stewardship__c ?: "" }

def check = { gln -> stewardshipRecords.find { it.Stewardship__c == (gln ?: "") }?.GLN__c ?: gln }


def updatedGrowerAddress = (stewardshipEnabled && totalSize > 0) 
    ? growerAddress.collect { item ->
        item?.PartnerInformation?.PartnerIdentifier 
            ? [PartnerInformation: item.PartnerInformation + [PartnerIdentifier: findgln(item.PartnerInformation.PartnerIdentifier)]]
            : item
    }
    : growerAddress
    
    
    
   
    
    
    
    
    
    
    
    def updatedGrowerGLN = growerGLN.collect { gln ->
    (stewardshipEnabled && stewardshipList.contains(gln ?: "")) ? check(gln) : gln
}


message.setProperty("growerGLN", JsonOutput.prettyPrint(JsonOutput.toJson(updatedGrowerGLN)))
message.setProperty("growerAddress", JsonOutput.prettyPrint(JsonOutput.toJson(updatedGrowerAddress)))



  

    return message;
}