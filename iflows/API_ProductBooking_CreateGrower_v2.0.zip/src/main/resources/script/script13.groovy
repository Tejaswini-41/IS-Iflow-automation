import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def jsonSlurper = new JsonSlurper()
    def payload = jsonSlurper.parseText(body)
    
    def result
    def glnList = []
    
    if (payload?.result?.items) {
        payload.result.items.each { item ->
            if (item?.Account__r?.GLN__c) {
                glnList << item.Account__r.GLN__c
            }
        }
    }
    
    if (glnList.size() > 1) {
        result = "DuplicateGLN"
    } else if (glnList.size() == 1) {
        result = glnList[0]
    } else {
        result = message.getProperty("Partner")
    }
    
    message.setProperty("setGLN" ,result)
    // message.setHeader("DebugPartner", result) // Debug log for Partner property
    return message
}