import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def processData(Message message) {
    def body = message.getBody(String)
    def payload = new JsonSlurper().parseText(body)
    def output = []

    // Helper functions
    def getCurrentYear = {
        def currentMonth = new Date().format("MM")
        def currentYear = new Date().format("yyyy").toInteger()
        if (["10", "11", "12"].contains(currentMonth)) {
            return (currentYear + 1).toString()
        }
        return currentYear.toString()
    }

    def checkYear = { DateYear, DateMonth ->
        def currentYear = getCurrentYear().toInteger()
        if (["10", "11", "12"].contains(DateMonth) && 
            ((DateYear.toInteger() + 1 == currentYear) || 
             (DateYear.toInteger() + 1 == currentYear - 1) || 
             (DateYear.toInteger() + 1 == currentYear + 1))) {
            return "Success"
        }
        if (["01", "02", "03", "04", "05", "06", "07", "08", "09"].contains(DateMonth) && 
            ((DateYear.toInteger() == currentYear) || 
             (DateYear.toInteger() == currentYear - 1) || 
             (DateYear.toInteger() == currentYear + 1))) {
            return "Success"
        }
        return "Failed"
    }

    // Process OrderChange
    def orderChangeBodies = payload.OrderChange?.OrderChangeBody
    if (!(orderChangeBodies instanceof List)) {
        orderChangeBodies = [orderChangeBodies]
    }

    orderChangeBodies.each { orderChangeBody ->
        def orderChangeProperties = orderChangeBody?.OrderChangeProperties
        def orderChangePartners = orderChangeBody?.OrderChangePartners
        def orderChangeDetails = orderChangeBody?.OrderChangeDetails

        def growerGLN = null
        def shipToPartnerIdentifier = orderChangePartners?.ShipTo?.PartnerInformation?.PartnerIdentifier
        if (shipToPartnerIdentifier instanceof List) {
            growerGLN = shipToPartnerIdentifier.find { it.length() >= 13 && it.length() <= 16 }
        } else if (shipToPartnerIdentifier?.length() >= 13 && shipToPartnerIdentifier?.length() <= 16) {
            growerGLN = shipToPartnerIdentifier
        }

        def result = [
            reqCustOrdNum: orderChangeProperties?.PurchaseOrderNumber?.DocumentIdentifier ?: "EC002",
            GrowerGLN: growerGLN,
            EC006: (["NE", "KN"].contains(orderChangeProperties?.PurchaseOrderTypeCode)) ? "Success" : "EC006",
            EC041: (checkYear((orderChangeProperties?.PurchaseOrderIssuedDate?.DateTime?.split("-")[0]), 
                              (orderChangeProperties?.PurchaseOrderIssuedDate?.DateTime?.split("-")[1])) == "Success") ? "Success" : "EC041",
            EC053: (growerGLN?.length() == 13) ? "Success" : "EC053",
            EC100: "Success",
            EC065: (!["", "9999999999", "0000000000"].contains(orderChangeProperties?.PurchaseOrderNumber?.DocumentIdentifier)) ? "Success" : "EC065",
            productItem: orderChangeDetails?.OrderChangeProductLineItem ? [orderChangeDetails?.OrderChangeProductLineItem].flatten().collect { item ->
                def measurementValue = item?.ProductQuantity?.Measurement?.MeasurementValue?.toString()?.toDouble() ?: 0.0
                [
                    GTIN: item?.ProductIdentification?.ProductIdentifier,
                    reqCustOrdLineNum: item?.PurchaseOrderLineItemNumber ?: "EC027",
                    EC027: (!["", "000000", "999999"].contains(item?.PurchaseOrderLineItemNumber)) ? "Success" : "EC027",
                    EC032: (item?.ProductQuantity?.Measurement?.UnitOfMeasureCode == "BG") ? "Success" : "EC032",
                    EC102: (["Add", "Replace", "Void", "Delete"].contains(item?.ActionRequest)) ? "Success" : "EC102",
                    EC109: (item?.ActionRequest?.toLowerCase() == "add" && measurementValue <= 0) ? "EC109" : "Success"
                ]
            } : []
        ]
        output << result
    }

    // Set the message body
    def outputJson = JsonOutput.prettyPrint(JsonOutput.toJson(output))
    // message.setBody(outputJson)

    // Set the output as a property
    message.setProperty("checkError", outputJson)
    return message
}