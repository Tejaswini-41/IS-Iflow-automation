import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def body = message.getBody(String)
    def jsonSlurper = new JsonSlurper()
    def payload = jsonSlurper.parseText(body)

    def seedYear = ""
    def contactInfo = payload.ProductBooking.Header.From.PartnerInformation.ContactInformation.find { it.ContactDescription == "SeedYear" }
    if (contactInfo?.ContactName) {
        seedYear = contactInfo.ContactName
    }
    def shipToList = []
    def ProductBookingBodies = payload.ProductBooking.ProductBookingBody
    if (!(ProductBookingBodies instanceof List)) {
       ProductBookingBodies = [ProductBookingBodies]
    }
    ProductBookingBodies.each { productBookingBody ->
        def shipToInfo = productBookingBody?.ProductBookingPartners?.ShipTo ?: [:]
        shipToList << shipToInfo
    }
    def outputJson = JsonOutput.toJson(shipToList)

    
    // Extract ProductIdentifiers
    def productIdentifiers = []
    ProductBookingBodies.each { productBookingBody ->
        def productBookingDetails = productBookingBody.ProductBookingDetails
        if (productBookingDetails instanceof List) {
            productBookingDetails.each { productBookingDetail ->
                def productLineItems = productBookingDetail .ProductBookingProductLineItem
                if (productLineItems instanceof List) {
                    productLineItems.each { productLineItem ->
                        def productIdentifier = productLineItem?.ProductIdentification?.ProductIdentifier
                        if (productIdentifier) {
                            productIdentifiers << productIdentifier
                        }
                    }
                } else if (productLineItems instanceof Map) {
                    def productIdentifier = productLineItems?.ProductIdentification?.ProductIdentifier
                    if (productIdentifier) {
                        productIdentifiers << productIdentifier
                    }
                }
            }
        } else if (productBookingDetails instanceof Map) {
            def productLineItems = productBookingDetails.ProductBookingProductLineItem
            if (productLineItems instanceof List) {
                productLineItems.each { productLineItem ->
                    def productIdentifier = productLineItem?.ProductIdentification?.ProductIdentifier
                    if (productIdentifier) {
                        productIdentifiers << productIdentifier
                    }
                }
            } else if (productLineItems instanceof Map) {
                def productIdentifier = productLineItems?.ProductIdentification?.ProductIdentifier
                if (productIdentifier) {
                    productIdentifiers << productIdentifier
                }
            }
        }
    }
    // Remove duplicates
    productIdentifiers = productIdentifiers.unique()
    
    // Map each element to add single quotes
    def quotedProductIdentifiers = productIdentifiers.collect { "'${it}'" }

    // Join the array back into a comma-separated string
    def GTINSeperatedCommas = quotedProductIdentifiers.join(',')
    def productIdentifiersJson = JsonOutput.toJson(productIdentifiers)
    def partnerIdentifier = payload.ProductBooking.Header.From.PartnerInformation.PartnerIdentifier ?: null
    if (partnerIdentifier instanceof List) {
        partnerIdentifier = partnerIdentifier.collect { "'${it}'" }
    } else if (partnerIdentifier) {
        partnerIdentifier = "'${partnerIdentifier}'"
    }

    def buyerPartnerIdentifiers = []
    ProductBookingBodies.each { ProductBookingBody ->
        def buyerInfo = ProductBookingBody?.ProductBookingPartners?.Buyer?.PartnerInformation?.PartnerIdentifier
        if (buyerInfo && buyerInfo instanceof List) {
            buyerPartnerIdentifiers << "'${buyerInfo[0]}'" // Access the first PartnerIdentifier and enclose in single quotes
        } else if (buyerInfo) {
            buyerPartnerIdentifiers << "'${buyerInfo}'" // Handle case where PartnerIdentifier is not a list and enclose in single quotes
        }
    }

    def resellerGLN = buyerPartnerIdentifiers.join(',')
    // Extract ShipTo.PartnerInformation.PartnerIdentifier
    def shipToPartnerIdentifiers = []
    ProductBookingBodies.each { productBookingBody ->
        def shipToInfo = productBookingBody?.ProductBookingPartners?.ShipTo?.PartnerInformation?.PartnerIdentifier
        if (shipToInfo) {
            shipToPartnerIdentifiers << shipToInfo
        }
    }
    // Remove duplicates
    shipToPartnerIdentifiers = shipToPartnerIdentifiers.unique()
    
    def growerGLNSeperatedCommas = shipToPartnerIdentifiers.join(',')
    
    def growerGLN = JsonOutput.toJson(shipToPartnerIdentifiers)

    // Set properties
    message.setProperty("seedYear", seedYear)
    message.setProperty("resellerGLN", resellerGLN)
    message.setProperty("partnerIdentifier", partnerIdentifier)
    message.setProperty("growerAddress", outputJson)
    message.setProperty("GTINSeperatedCommas", GTINSeperatedCommas)
    message.setProperty("growerGLN", growerGLN)
    message.setProperty("growerGLNSeperatedCommas", growerGLNSeperatedCommas)
    message.setProperty("GTIN", productIdentifiersJson)

    return message
}