import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

def Message processData(Message message) {
    // Retrieve the input payload from the message body
    def messageBody = message.getBody(java.lang.String) as String
    def jsonSlurper = new JsonSlurper()
    def payload = jsonSlurper.parseText(messageBody)

    // Extract values from the payload
    def faultcode = payload.faultcode ?: 'soapenv:Client'
    def faultstring = payload.faultstring ?: 'Unable to Process Request'
    def reason = payload.reason ?: 'Invalid Business Process Requested.'
    def node = payload.node ?: 'Received response code 500 from backend server'
    def path = payload.path ?: 'request-pipeline'

    // Manually construct the XML string with double quotes for namespaces
    def xml = """<?xml version='1.0' encoding='UTF-8'?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
  <soapenv:Header/>
  <soapenv:Body>
    <soapenv:Fault>
      <faultcode>${faultcode}</faultcode>
      <faultstring>${faultstring}</faultstring>
      <detail>
        <con:fault xmlns:con="http://www.bea.com/wli/sb/context">
          <con:reason>${reason}</con:reason>
          <con:location>
            <con:node>${node}</con:node>
            <con:path>${path}</con:path>
          </con:location>
        </con:fault>
      </detail>
    </soapenv:Fault>
  </soapenv:Body>
</soapenv:Envelope>"""

    // Set the generated XML as the message body
    message.setBody(xml.toString())
    message.setHeader("Content-Type", "application/xml")

    return message
}