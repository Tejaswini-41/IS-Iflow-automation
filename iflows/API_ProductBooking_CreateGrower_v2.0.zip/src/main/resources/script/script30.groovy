import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    def properties = message.getProperties()
    
    def setErrorList = new JsonSlurper().parseText(properties.get("setErrorList"))
    def resellerGLN = properties.get("resellerGLN")?.replaceAll("'", "") 
    def seedYear = properties.get("seedYear")

    def getGrowerStatus = { custnum, Grower ->
        setErrorList.orderDetail.find { it.GrowerGLN == Grower && it.reqCustOrdNum == custnum }
    }

    def geterrorGrower = { custnum, Grower ->
        setErrorList.orderDetail.find { it.GrowerGLN == Grower && it.reqCustOrdNum == custnum }?.HeaderError
    }

    def geterrorProduct = { custnum, Grower, GTIN ->
        setErrorList.orderDetail.find { it.GrowerGLN == Grower && it.reqCustOrdNum == custnum }?.productItem?.find { it.GTIN == GTIN }?.LineError
    }

    def payload = new JsonSlurper().parseText(message.getBody(String))
    
    def result = [
        newGrowers: [
            resellerGLN: setErrorList.resellerGLN,
            growers: setErrorList.growers
        ],
        orderDetail: []
    ]

    def orderChange = payload.OrderChange
    def orderChangeBodies = orderChange.OrderChangeBody
    if (!(orderChangeBodies instanceof List)) {
        orderChangeBodies = [orderChangeBodies]
    }

    orderChangeBodies.each { value ->
        def reqCustOrdNum = value.OrderChangeProperties.PurchaseOrderNumber.DocumentIdentifier
        def shipToInfo = value?.OrderChangePartners?.ShipTo?.PartnerInformation?.PartnerIdentifier
        def GrowerGLN = null

        if (shipToInfo instanceof List) {
            GrowerGLN = shipToInfo.find { it?.length() >= 13 && it?.length() <= 16 }
        } else if (shipToInfo instanceof String && shipToInfo?.length() >= 13 && shipToInfo?.length() <= 16) {
            GrowerGLN = shipToInfo
        }
        def orderDetail = [
            reqDocIdentifier: orderChange.Header.ThisDocumentIdentifier.DocumentIdentifier ?: null,
            reqSynOrdNum: (value.OrderChangeProperties.ReferenceInformation.DocumentReference.DocumentIdentifier.startsWith("SO-") || value.OrderChangeProperties.ReferenceInformation.DocumentReference.DocumentIdentifier == "9999999999") ? value.OrderChangeProperties.ReferenceInformation.DocumentReference.DocumentIdentifier : "SO-20" + value.OrderChangeProperties.ReferenceInformation.DocumentReference.DocumentIdentifier,
            reqPayerGLN: value.OrderChangePartners.Payer.PartnerInformation.PartnerIdentifier,
            reqBuyerGLN: GrowerGLN,
            reqBuyerSFDCId: getGrowerStatus(reqCustOrdNum, GrowerGLN)?.growerSFDCId ?: getGrowerStatus(reqCustOrdNum, GrowerGLN)?.GrowerGLN,
            reqSellerGLN: resellerGLN,
            reqSeedYear: seedYear,
            reqCustOrdNum: reqCustOrdNum,
            respExceptions: geterrorGrower(reqCustOrdNum, GrowerGLN) ?: [],
            productItem: []
        ]

        def orderChangeDetails = value.OrderChangeDetails
        def productLineItems = orderChangeDetails.OrderChangeProductLineItem
        if (!(productLineItems instanceof List)) {
            productLineItems = [productLineItems]
        }

        productLineItems.each { value1 ->
            def GTIN = value1.ProductIdentification.ProductIdentifier
            def productItem = [
                reqProdGTIN: GTIN,
                reqProdQty: value1.ProductQuantity.Measurement.MeasurementValue,
                reqType: value1.ActionRequest == "Replace" ? "Change" : value1.ActionRequest == "Void" ? "Delete" : value1.ActionRequest,
                reqRDD: value1.ScheduleDateTimeInformation.DateTimeInformation.DateTime,
                reqCustOrdLineNum: value1.PurchaseOrderLineItemNumber,
                reqSynOrdLineNum: value1.LineNumber,
                reqM2MOrderRef: reqCustOrdNum + "|" + value1.PurchaseOrderLineItemNumber,
                respExceptions: geterrorProduct(reqCustOrdNum, GrowerGLN, GTIN) ?: []
            ]
            orderDetail.productItem << productItem
        }

        result.orderDetail << orderDetail
    }

    message.setProperty("sfRequest",JsonOutput.prettyPrint(JsonOutput.toJson(result)))
    return message
}