
import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Parse the input data
    def payload = new JsonSlurper().parseText(message.getBody(String))
    def setErrorList = new JsonSlurper().parseText(message.getProperty("setErrorList"))

    def growerAddressInput = new JsonSlurper().parseText(message.getProperty("growerAddress"))
    def growerGLNInput = new JsonSlurper().parseText(message.getProperty("growerGLN"))

    // Extract values from compositeResponse with proper array indexing and type conversion
    // def stewardshipEnabled = payload.result?.compositeResponse[1]?.body?.records[0]?.StewarshipEnabled__c 
    // def blockOrders = payload.result?.compositeResponse[1]?.body?.records[0]?.BlockOrders__c 
    
    
    //changeing to
    def stewarshipRec = payload.result?.compositeResponse[1]?.body?.records
    if (stewarshipRec instanceof List) {
    stewarshipRec = stewarshipRec[0]
    }
    def stewardshipEnabled = stewarshipRec?.StewarshipEnabled__c
    def blockOrders = stewarshipRec?.BlockOrders__c
    
    message.setProperty("stewardshipEnabled",stewardshipEnabled)
    message.setProperty("blockOrders",blockOrders)

    def recordsData = payload.result?.compositeResponse[2]?.body?.records
    def stewardshipRecords = []
    if (recordsData) {
        stewardshipRecords = (recordsData instanceof List) ? recordsData : [recordsData]
    }
    def totalSize = (payload.result?.compositeResponse[2]?.body?.totalSize ?: 0) as Integer

    // Create stewardship lookup map
    def stewardshipLookup = stewardshipRecords.collectEntries { record ->
        [(record.Stewardship__c): record.GLN__c]
    }

    // Function to find GLN mapping
    def findgln = { gln ->
        (stewardshipEnabled == "true" && stewardshipLookup.containsKey(gln)) 
            ? stewardshipLookup[gln] 
            : gln
    }

    // Process growerAddress
    def updatedGrowerAddress = growerAddressInput
    if (stewardshipEnabled == "true" && totalSize > 0) {
        updatedGrowerAddress = growerAddressInput.collect { item ->
            def partnerInfo = item.PartnerInformation
            def originalIdentifier = partnerInfo.PartnerIdentifier
            def newIdentifier = findgln(originalIdentifier) ?: originalIdentifier
            
            def updatedPartnerInfo = partnerInfo.clone()
            updatedPartnerInfo.PartnerIdentifier = newIdentifier
            
            return [PartnerInformation: updatedPartnerInfo]
        }
    }

    // Function to change grower GLN
    def changegrower = { gln ->
        (stewardshipEnabled == "true" && stewardshipLookup.containsKey(gln)) 
            ? stewardshipLookup[gln] 
            : gln
    }

    // Process growerGLN array
    def updatedGrowerGLN = growerGLNInput.collect { gln ->
        (stewardshipEnabled == "true" && stewardshipLookup.containsKey(gln)) 
            ? stewardshipLookup[gln] 
            : gln
    }

    // Process the setErrorList
    def updatedErrorList = setErrorList.collect { item ->
        def actualGrowerGLN = item.GrowerGLN
        def newGrowerGLN = actualGrowerGLN
        
        // Apply changegrower logic if StewardshipEnabled is true
        if (stewardshipEnabled == "true") {
            newGrowerGLN = changegrower(actualGrowerGLN)
        }

        // Start with existing HeaderError
        def headerError = item.HeaderError ?: []

        // Add BlockOrders error if applicable
        if (blockOrders == "true") {
            headerError << [
                "id": "999",
                "description": "Syngenta Internal Error – Please contact Syngenta",
                "comments": "Syngenta M2M orders are currently blocked; Please contact Syngenta customer services if you have any questions"
            ]
        }

        // Add Stewardship mapping error if applicable
        def growerGLN = actualGrowerGLN ?: ""
        if (growerGLN.contains("US03") && 
            stewardshipEnabled == "true" && 
            !stewardshipLookup.containsKey(actualGrowerGLN)) {
            headerError << [
                "id": "999",
                "description": "Syngenta Internal Error – Please contact Syngenta",
                "comments": "Unable to map the Stewardship number ${growerGLN} to a GLN, Grower not found"
            ]
        }

        return [
            "reqCustOrdNum": item.reqCustOrdNum,
            "ActualGrowerGLN": actualGrowerGLN,
            "GrowerGLN": newGrowerGLN,
            "HeaderError": headerError,
            "productItem": item.productItem
        ]
    }

    // Convert the updated data to JSON
    def setGrowersResult = JsonOutput.prettyPrint(JsonOutput.toJson(updatedErrorList))
    def growerAddressResult = JsonOutput.prettyPrint(JsonOutput.toJson(updatedGrowerAddress))
    def growerGLNResult = JsonOutput.prettyPrint(JsonOutput.toJson(updatedGrowerGLN))
    def newGrowerGLNSeperatedcommas = updatedGrowerGLN.join(',')
    
    // Set properties
    message.setProperty("setGrowers", setGrowersResult)
    message.setProperty("setErrorList", setGrowersResult)
    message.setProperty("growerAddress", growerAddressResult)
    message.setProperty("growerGLN", growerGLNResult)
    message.setProperty("newGrowerGLNSeperatedcommas", newGrowerGLNSeperatedcommas)
    message.setProperty("growerGLNSeperatedCommas", newGrowerGLNSeperatedcommas)
    message.setProperty("stewardshipLookup", JsonOutput.toJson(stewardshipLookup))
    message.setProperty("stewardshipEnabled", stewardshipEnabled.toString())
    
    return message
}