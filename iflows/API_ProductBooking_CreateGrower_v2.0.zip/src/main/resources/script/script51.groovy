import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message processData(Message message) {
    // Retrieve headers
    def headers = message.getHeaders()
    def M2MInputJson = headers.get("M2MInput")
    def ResponseLogXml = headers.get("ResponseLog")

    // Parse JSON and XML
    def M2MInput = new JsonSlurper().parseText(M2MInputJson)
    def ResponseLog = new XmlSlurper().parseText(ResponseLogXml)

    // Determine status
    def statusIdentifier = ResponseLog.Body?.outboundData?.xmlPayload?.OrderResponse?.OrderResponseBody?.OrderResponseProperties?.ResponseStatus?.ResponseStatusReasonIdentifier?.text()
    if (!statusIdentifier) {
        statusIdentifier = ResponseLog.Body?.outboundData?.xmlPayload?.ProductBookingResponse?.ProductBookingResponseBody?.ProductBookingResponseProperties?.ResponseStatus?.ResponseStatusReasonIdentifier?.text()
    }
    def status = (statusIdentifier == "098" || statusIdentifier == "000") ? "Completed" : "Failed"

    // Construct output with null checks
    def output = [
        ResponseStatus__c: M2MInput.ResponseStatus__c ?: "",
        ResellerName__c: M2MInput.ResellerName__c ?: "",
        ResellerGLN__c: M2MInput.ResellerGLN__c ?: "",
        GrowerName__c: M2MInput.GrowerName__c ?: "",
        GrowerGLN__c: M2MInput.GrowerGLN__c ?: "",
        Type__c: "M2MLog",
        Status__c: status,
        CustomerSalesOrderNum__c: ResponseLog.Body?.outboundData?.xmlPayload?.OrderResponse?.OrderResponseBody?.OrderResponseProperties?.PurchaseOrderNumber?.DocumentIdentifier?.text() ?: ResponseLog.Body?.outboundData?.xmlPayload?.ProductBookingResponse?.ProductBookingResponseBody?.ProductBookingResponseProperties?.ProductBookingOrderNumber?.text() ?: "",
        SyngentaSalesOrderNum__c: ResponseLog.Body?.outboundData?.xmlPayload?.OrderResponse?.OrderResponseBody?.OrderResponseProperties?.ReferenceInformation?.DocumentReference?.DocumentIdentifier?.text() ?: ResponseLog.Body?.outboundData?.xmlPayload?.ProductBookingResponse?.ProductBookingResponseBody?.ProductBookingResponseProperties?.ReferenceInformation?.DocumentReference?.DocumentIdentifier?.text() ?: "",
        ErrorDescription__c: ResponseLog.Body?.outboundData?.xmlPayload?.OrderResponse?.OrderResponseBody?.OrderResponseProperties?.ResponseStatus?.ResponseStatusReasonDescription?.text() ?: ResponseLog.Body?.outboundData?.xmlPayload?.ProductBookingResponse?.ProductBookingResponseBody?.ProductBookingResponseProperties?.ResponseStatus?.ResponseStatusReasonDescription?.text() ?: ""
    ]

    // Set the output as the message body with pretty print
    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(output)))
    return message
}