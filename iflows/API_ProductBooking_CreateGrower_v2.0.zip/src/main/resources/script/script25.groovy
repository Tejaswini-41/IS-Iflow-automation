import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Get the payload as a string
    def body = message.getBody(String)
    
    // Parse the JSON payload
    def jsonSlurper = new JsonSlurper()
    def payload = jsonSlurper.parseText(body)
    
    // Check the first set of conditions
    def resellerId = null
    if (payload.result.compositeResponse[0].httpStatusCode == "200" && 
        payload.result.compositeResponse[0].body.totalSize != null && 
        payload.result.compositeResponse[0].body.totalSize.toInteger() > 0) {
        resellerId = payload.result.compositeResponse[0].body.records.Id
    }
    
    // Set the resellerId property
    message.setProperty("resellerId", resellerId)
    
    // Check the second set of conditions
    def records = []
    if (payload.result.compositeResponse[1].httpStatusCode == "200" && 
        payload.result.compositeResponse[1].body.totalSize != null && 
        payload.result.compositeResponse[1].body.totalSize.toInteger() > 0) {
        records = payload.result.compositeResponse[1].body.records
        if (!(records instanceof List)) {
            records = [records]
        }
    }
    
    // Convert records to JSON string
    def recordsJson = JsonOutput.toJson(records)
    
    // Set the records property as JSON
    message.setProperty("PMRXRef_GTINs", recordsJson)
    
    // Check the third set of conditions and create the query string
    def PMRXRef_products = ""
    if (payload.result.compositeResponse[1].httpStatusCode == "200" && 
        payload.result.compositeResponse[1].body.totalSize != null && 
        payload.result.compositeResponse[1].body.totalSize.toInteger() > 0) {
        def productReferences = records.collect { record ->
            record.giic_Material_Number__r?.gii__ProductReference__c
        }.findAll { it != null }.collect { "'${it}'" }
        PMRXRef_products = "OR ID in (${productReferences.join(',')})"
    }
    
    // Set the queryString property
    message.setProperty("PMRXRef_products", PMRXRef_products)
    
    return message
}