import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def partnerIdentifier = message.getProperty("PartnerIdentifier")
    def resellerGLN = message.getProperty("resellerGLN")
    def result

    if (partnerIdentifier != null) {
        result = partnerIdentifier
    } else if (resellerGLN != null) {
        result = resellerGLN
    } else {
        result = null
    }

    message.setProperty("Partner", result)
    return message
}