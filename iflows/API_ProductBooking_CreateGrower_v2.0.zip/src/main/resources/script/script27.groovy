import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Parse the setErrorList property
    def setErrorListJson = message.getProperty("setErrorList")
    def setErrorList = new JsonSlurper().parseText(setErrorListJson)
    
    // Parse the ErrorCodes property
    def errorCodesJson = message.getProperty("ErrorCodes")
    def errorCodes = new JsonSlurper().parseText(errorCodesJson)
    
    // Process the data and generate the output
    def output = [
        resellerGLN: setErrorList.resellerGLN,
        growers: setErrorList.growers,
        orderDetail: setErrorList.orderDetail.collect { item ->
            [
                reqCustOrdNum: item.reqCustOrdNum,
                GrowerGLN: item.GrowerGLN,
                ActualGrowerGLN:item.ActualGrowerGLN,
                reqDocIdentifier: item.reqDocIdentifier,
                growerSFDCId: item.growerSFDCId,
                growerSFDCStatus: item.growerSFDCStatus,
                HeaderError: item.HeaderError,
                productItem: item.productItem.collect { item1 ->
                    [
                        GTIN: item1.GTIN,
                        reqCustOrdLineNum: item1.reqCustOrdLineNum,
                        LineError: (item1.LineError + [
                            id: "030",
                            description: errorCodes.EC030.split("-")[0],
                            comments: errorCodes.EC030.split("-")[1]
                        ]) ?: [
                            [
                                id: "030",
                                description: errorCodes.EC030.split("-")[0],
                                comments: errorCodes.EC030.split("-")[1]
                            ]
                        ]
                    ]
                }
            ]
        }
    ]
    
    // Set the output as the message body with pretty print
    def prettyOutput = JsonOutput.prettyPrint(JsonOutput.toJson(output))
    // message.setBody(prettyOutput)
    
    // Set the output as a property named setErrorList
    message.setProperty("setErrorList", prettyOutput)
    
    
    
    return message
}