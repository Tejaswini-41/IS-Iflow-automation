import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {
    // Parse the incoming body
    def body = message.getBody(String)
    def payload = new JsonSlurper().parseText(body)

    // Filter and map the growers
    def filteredGrowers = payload.growers.findAll { it.status != "Success" }.collect { grower ->
        def result = ["grower": grower.gln]
        if (grower.respException != null) {
            result["respException"] = grower.respException
        }
        return result
    }

    // Create the final output
    def result = JsonOutput.prettyPrint(JsonOutput.toJson(filteredGrowers))
    message.setBody(result)
    message.setProperty("failedRecords",result)
    
    def failedRecordsList = new JsonSlurper().parseText(result)
    if (failedRecordsList.size() < 1) {
        // Route condition for empty failedRecords
        message.setProperty("FailedRecordsEmpty", true)
    } else {
        // Route condition for non-empty failedRecords
        message.setProperty("FailedRecordsEmpty", false)
    }
    
    
    return message
}