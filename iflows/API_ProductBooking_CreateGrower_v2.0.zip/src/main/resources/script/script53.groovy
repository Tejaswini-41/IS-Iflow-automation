import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def jsonSlurper = new JsonSlurper()
    def payload = jsonSlurper.parseText(body)

    def responseStatus = ""
    if (payload.OrderChange) {
        def contactInfo = payload.OrderChange.Header.From.PartnerInformation.ContactInformation.find { it.ContactDescription == "SeedYear" }
        if (contactInfo?.ContactName) {
            responseStatus = contactInfo.ContactName
        }
    } else if (payload.ProductBooking) {
        def contactInfo = payload.ProductBooking.Header.From.PartnerInformation.ContactInformation.find { it.ContactDescription == "SeedYear" }
        if (contactInfo?.ContactName) {
            responseStatus = contactInfo.ContactName
        }
    }

    // def growerGLN = null
    // def shipToPartnerIdentifier = payload?.OrderChange?.OrderChangeBody?.OrderChangePartners?.ShipTo?.PartnerInformation?.PartnerIdentifier
    // if (shipToPartnerIdentifier instanceof List) {
    //     growerGLN = shipToPartnerIdentifier.find { it.length() >= 13 && it.length() <= 16 }
    // } else if (shipToPartnerIdentifier?.length() >= 13 && shipToPartnerIdentifier?.length() <= 16) {
    //     growerGLN = shipToPartnerIdentifier
    // } else {
    //     shipToPartnerIdentifier = payload?.ProductBooking?.ProductBookingBody?.ProductBookingPartners?.ShipTo?.PartnerInformation?.PartnerIdentifier
    //     if (shipToPartnerIdentifier instanceof List) {
    //         growerGLN = shipToPartnerIdentifier.find { it.length() >= 13 && it.length() <= 16 }
    //     } else if (shipToPartnerIdentifier?.length() >= 13 && shipToPartnerIdentifier?.length() <= 16) {
    //         growerGLN = shipToPartnerIdentifier
    //     }
    // }

    def result = [
        ResponseStatus__c: responseStatus,
        ResellerName__c: payload.OrderChange ? payload.OrderChange.Header.From.PartnerInformation.PartnerName : payload.ProductBooking?.Header.From.PartnerInformation.PartnerName,
        ResellerGLN__c: payload.OrderChange ? payload.OrderChange.Header.From.PartnerInformation.PartnerIdentifier : payload.ProductBooking?.Header.From.PartnerInformation.PartnerIdentifier,
        GrowerName__c: payload.OrderChange ? payload.OrderChange.OrderChangeBody.OrderChangePartners.ShipTo.PartnerInformation.PartnerName : payload.ProductBooking?.ProductBookingBody.ProductBookingPartners.ShipTo.PartnerInformation.PartnerName,
        GrowerGLN__c: payload.OrderChange ? payload?.OrderChange?.OrderChangeBody?.OrderChangePartners?.ShipTo?.PartnerInformation?.PartnerIdentifier : payload.ProductBooking?.ProductBookingBody?.ProductBookingPartners?.ShipTo?.PartnerInformation?.PartnerIdentifier,
        Type__c: "M2MLog",
        Status__c: "",
        CustomerSalesOrderNum__c: payload.OrderChange ? payload.OrderChange.OrderChangeBody.OrderChangeProperties.PurchaseOrderNumber.DocumentIdentifier : payload.ProductBooking?.ProductBookingBody.ProductBookingProperties.ProductBookingOrderNumber,
        SyngentaSalesOrderNum__c: ""
    ]

    message.setProperty("M2MInput", JsonOutput.toJson(result))
    // message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(result)))
    return message
}