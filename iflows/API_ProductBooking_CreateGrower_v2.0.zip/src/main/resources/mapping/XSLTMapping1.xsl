<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:urn="urn:cidx:names:specification:ces:schema:all:5.0"
                xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" exclude-result-prefixes="soapenv">
    <xsl:output method="xml" indent="yes"/>
    
    <!-- Define the requiredField constant -->
    <xsl:param name="RequiredField"/>
    <xsl:variable name="OrderChangePrefix" select="substring-before(name(soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange']), ':')"/>
    <xsl:variable name="OrderChangeNamespace" select="namespace-uri(soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange'])"/>
    <xsl:variable name="CidxPrefix" select="substring-before(name(soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange']/*[local-name()='Header']), ':')"/>
    <xsl:variable name="CidxNamespace" select="namespace-uri(soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange']/*[local-name()='Header'])"/>
    
    <!-- Define the template for the root element -->
    <xsl:template match="/">
        <!-- Generate current datetime -->
        <xsl:variable name="currDateTime">
            <xsl:value-of select="concat(substring(current-dateTime(), 1, 10), 'T', substring(current-dateTime(), 12, 8), 'Z')"/>
        </xsl:variable>

        <urn:OrderResponse>
            <urn:Header>
                <urn:ThisDocumentIdentifier>
                    <urn:DocumentIdentifier>
                        <xsl:value-of select="soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange']/*[local-name()='Header']/*[local-name()='ThisDocumentIdentifier']/*[local-name()='DocumentIdentifier']"/>
                    </urn:DocumentIdentifier>
                </urn:ThisDocumentIdentifier>
                <urn:ThisDocumentDateTime>
                    <urn:DateTime DateTimeQualifier="On">
                        <xsl:value-of select="$currDateTime"/>
                    </urn:DateTime>
                </urn:ThisDocumentDateTime>
                <urn:From>
                    <xsl:apply-templates select="soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange']/*[local-name()='Header']/*[local-name()='To']/*"/>
                </urn:From>
                <urn:To>
                    <xsl:apply-templates select="soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange']/*[local-name()='Header']/*[local-name()='From']/*"/>
                </urn:To>
            </urn:Header>
            <xsl:for-each select="soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange']/*[local-name()='OrderChangeBody']">
                <urn:OrderResponseBody>
                    <urn:OrderResponseProperties>
                        <xsl:apply-templates select="*[local-name()='OrderChangeProperties']/*"/>
                        <urn:ResponseStatus>
                            <urn:ResponseStatusReasonIdentifier Agency="ECMS">E</urn:ResponseStatusReasonIdentifier>
                            <urn:ResponseStatusReasonDescription>
                                <xsl:value-of select="$RequiredField"/>
                            </urn:ResponseStatusReasonDescription>
                        </urn:ResponseStatus>
                    </urn:OrderResponseProperties>
                    <urn:OrderResponsePartners>
                        <xsl:apply-templates select="*[local-name()='OrderChangePartners']/*"/>
                    </urn:OrderResponsePartners>
                    <urn:OrderResponseDetails>
                        <xsl:for-each select="*[local-name()='OrderChangeDetails']/*[local-name()='OrderChangeProductLineItem']">
                            <urn:OrderResponseProductLineItem>
                                <xsl:apply-templates select="*"/>
                            </urn:OrderResponseProductLineItem>
                        </xsl:for-each>
                    </urn:OrderResponseDetails>
                </urn:OrderResponseBody>
            </xsl:for-each>
        </urn:OrderResponse>
    </xsl:template>

    <!-- Template for elements with urn namespace -->
    <xsl:template match="*[namespace-uri()='urn:cidx:names:specification:ces:schema:all:5.0']">
        <xsl:element name="urn:{local-name()}">
            <xsl:apply-templates select="@* | node()"/>
        </xsl:element>
    </xsl:template>

    <!-- Template for elements with dynamic cidx namespace -->
    <xsl:template match="*[namespace-uri()=$CidxNamespace]">
        <xsl:choose>
            <xsl:when test="$CidxPrefix != '' and $CidxNamespace != ''">
                <xsl:element name="{$CidxPrefix}:{local-name()}" namespace="{$CidxNamespace}"> <!-- Add dynamic prefix and namespace here -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:when>
            <xsl:otherwise>
                <xsl:element name="{local-name()}" namespace="{$CidxNamespace}"> <!-- Handle without prefix but with dynamic namespace -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- Template for elements with dynamic ns1 namespace -->
    <xsl:template match="*[namespace-uri()=$OrderChangeNamespace]">
        <xsl:choose>
            <xsl:when test="$OrderChangePrefix != '' and $OrderChangeNamespace != ''">
                <xsl:element name="{$OrderChangePrefix}:{local-name()}" namespace="{$OrderChangeNamespace}"> <!-- Add dynamic prefix and namespace here -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:when>
            <xsl:otherwise>
                <xsl:element name="{local-name()}" namespace="{$OrderChangeNamespace}"> <!-- Handle without prefix but with dynamic namespace -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    
    <!-- Template for attributes -->
    <xsl:template match="@*">
        <xsl:attribute name="{local-name()}">
            <xsl:value-of select="."/>
        </xsl:attribute>
    </xsl:template>
</xsl:stylesheet>