<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:cidx5_3="urn:cidx:names:specification:ces:schema:all:6.0"
                xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" exclude-result-prefixes="soapenv">
    <xsl:output method="xml" indent="yes"/>
    <xsl:param name="RequiredField"/>
    <xsl:variable name="businessProcess" select="soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='businessProcess']"/>
     <xsl:variable name="Prefix" select="substring-before(name(soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking']), ':')"/>
    <xsl:variable name="Namespace" select="namespace-uri(soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking'])"/>
    
    <xsl:template match="/">
        <xsl:choose>
            <xsl:when test="$businessProcess = 'ProductBookingWS' or $businessProcess = 'Pro-ProductBookingWS' ">
                <cidx5_3:ProductBookingResponse>
                    <cidx5_3:Header>
                        <cidx5_3:ThisDocumentIdentifier>
                            <cidx5_3:DocumentIdentifier>
                                <xsl:value-of select="soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking']/*[local-name()='Header']/*[local-name()='ThisDocumentIdentifier']/*[local-name()='DocumentIdentifier']"/>
                            </cidx5_3:DocumentIdentifier>
                        </cidx5_3:ThisDocumentIdentifier>
                        <cidx5_3:ThisDocumentDateTime>
                            <cidx5_3:DateTime DateTimeQualifier="On">
                                <xsl:value-of select="current-dateTime()"/>
                            </cidx5_3:DateTime>
                        </cidx5_3:ThisDocumentDateTime>
                        <cidx5_3:From>
                            <xsl:apply-templates select="soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking']/*[local-name()='Header']/*[local-name()='To']/*"/>
                        </cidx5_3:From>
                        <cidx5_3:To>
                            <xsl:apply-templates select="soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking']/*[local-name()='Header']/*[local-name()='From']/*"/>
                        </cidx5_3:To>
                    </cidx5_3:Header>
                    <xsl:for-each select="soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking']/*[local-name()='ProductBookingBody']">
                        <cidx5_3:ProductBookingResponseBody>
                            <cidx5_3:ProductBookingResponseProperties>
                                <xsl:apply-templates select="*[local-name()='ProductBookingProperties']/*"/>
                                <cidx5_3:ResponseStatus>
                                    <cidx5_3:ResponseStatusReasonIdentifier Agency="SUPPLIER">E</cidx5_3:ResponseStatusReasonIdentifier>
                                    <cidx5_3:ResponseStatusReasonDescription>
                                        <xsl:value-of select="$RequiredField"/>
                                    </cidx5_3:ResponseStatusReasonDescription>
                                </cidx5_3:ResponseStatus>
                            </cidx5_3:ProductBookingResponseProperties>
                            <cidx5_3:ProductBookingResponsePartners>
                                <xsl:apply-templates select="*[local-name()='ProductBookingPartners']/*"/>
                            </cidx5_3:ProductBookingResponsePartners>
                            <cidx5_3:ProductBookingResponseDetails>
                                <xsl:for-each select="*[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem']">
                                    <cidx5_3:ProductBookingResponseProductLineItem>
                                        <xsl:apply-templates select="*"/>
                                    </cidx5_3:ProductBookingResponseProductLineItem>
                                </xsl:for-each>
                            </cidx5_3:ProductBookingResponseDetails>
                        </cidx5_3:ProductBookingResponseBody>
                    </xsl:for-each>
                </cidx5_3:ProductBookingResponse>
            </xsl:when>
        </xsl:choose>
    </xsl:template>

    <!-- Template for elements with specific namespaces -->
    <xsl:template match="*[namespace-uri()='urn:cidx:names:specification:ces:schema:all:6.0']">
        <xsl:element name="cidx:{local-name()}" namespace="urn:cidx:names:specification:ces:schema:all:6.0">
            <xsl:apply-templates select="@* | node()"/>
        </xsl:element>
    </xsl:template>

    <!-- Template for elements with dynamic namespace -->
    <xsl:template match="*[namespace-uri()=$Namespace]">
        <xsl:choose>
            <xsl:when test="$Prefix != '' and $Namespace != ''">
                <xsl:element name="{$Prefix}:{local-name()}" namespace="{$Namespace}"> <!-- Add dynamic prefix and namespace here -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:when>
            <xsl:otherwise>
                <xsl:element name="{local-name()}" namespace="{$Namespace}"> <!-- Handle without prefix but with dynamic namespace -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- Template for attributes -->
    <xsl:template match="@*">
        <xsl:attribute name="{local-name()}">
            <xsl:value-of select="."/>
        </xsl:attribute>
    </xsl:template>

    <!-- Generic template to copy elements as they are -->
    <xsl:template match="*">
        <xsl:element name="{local-name()}" namespace="{namespace-uri()}">
            <xsl:apply-templates select="@* | node()"/>
        </xsl:element>
    </xsl:template>
</xsl:stylesheet>