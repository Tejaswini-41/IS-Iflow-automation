<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:urn="urn:cidx:names:specification:ces:schema:all:6.0"
                xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" exclude-result-prefixes="soapenv">
    <xsl:output method="xml" indent="yes"/>
    
    <!-- Define a variable for the current date and time -->
    <xsl:variable name="currDateTime" select="concat(substring(current-dateTime(), 1, 10), 'T', substring(current-dateTime(), 12, 8), 'Z')"/>
    
    <!-- Define a key to quickly access response data by order number and line number -->
    <xsl:key name="responseKey" match="response" use="concat(reqCustOrdNum, '|', reqCustOrdLineNum)"/>
    <xsl:variable name="Prefix" select="substring-before(name(root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking']), ':')"/>
    <xsl:variable name="Namespace" select="namespace-uri(root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking'])"/>
    <xsl:variable name="businessProcess" select="root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='businessProcess']"/>
    
    <xsl:template match="/">
        <urn:ProductBookingResponse>
            <urn:Header>
                <urn:ThisDocumentIdentifier>
                    <urn:DocumentIdentifier>
                        <xsl:value-of select="root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking']/*[local-name()='Header']/*[local-name()='ThisDocumentIdentifier']/*[local-name()='DocumentIdentifier']"/>
                    </urn:DocumentIdentifier>
                </urn:ThisDocumentIdentifier>
                <urn:ThisDocumentDateTime>
                    <urn:DateTime DateTimeQualifier="On">
                        <xsl:value-of select="$currDateTime"/>
                    </urn:DateTime>
                </urn:ThisDocumentDateTime>
                <urn:From>
                    <xsl:apply-templates select="root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking']/*[local-name()='Header']/*[local-name()='To']/*"/>
                </urn:From>
                <urn:To>
                    <xsl:apply-templates select="root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking']/*[local-name()='Header']/*[local-name()='From']/*"/>
                </urn:To>
            </urn:Header>
            <xsl:for-each select="root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking']/*[local-name()='ProductBookingBody']">
                <urn:ProductBookingResponseBody>
                    <urn:ProductBookingResponseProperties>
                        <urn:ProductBookingType>
                            <xsl:value-of select="*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingType']"/>
                        </urn:ProductBookingType>
                        <urn:ProductBookingOrderNumber>
                            <xsl:value-of select="*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber']"/>
                        </urn:ProductBookingOrderNumber>
                        <urn:ProductBookingOrderTypeCode>
                            <xsl:value-of select="*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderTypeCode']"/>
                        </urn:ProductBookingOrderTypeCode>
                        <urn:ProductBookingOrderIssuedDate>
                            <xsl:apply-templates select="*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderIssuedDate']/*"/>
                        </urn:ProductBookingOrderIssuedDate>
                        <urn:LanguageCode Domain="ISO-639-2T">
                            <xsl:value-of select="*[local-name()='ProductBookingProperties']/*[local-name()='LanguageCode']"/>
                        </urn:LanguageCode>
                        <urn:CurrencyCode Domain="ISO-4217">
                            <xsl:value-of select="*[local-name()='ProductBookingProperties']/*[local-name()='CurrencyCode']"/>
                        </urn:CurrencyCode>
                        <urn:BuyerSequenceNumber>
                            <xsl:value-of select="format-number(*[local-name()='ProductBookingProperties']/*[local-name()='BuyerSequenceNumber'], '00000000')"/>
                        </urn:BuyerSequenceNumber>
                        <xsl:if test="normalize-space(*[local-name()='ProductBookingProperties']/*[local-name()='SoftwareInformation']) != ''">
                        <urn:SoftwareInformation>
                            <urn:SoftwareSource>
                                <xsl:value-of select="*[local-name()='ProductBookingProperties']/*[local-name()='SoftwareInformation']/*[local-name()='SoftwareSource']"/>
                            </urn:SoftwareSource>
                            <urn:SoftwareVersion>
                                <xsl:value-of select="*[local-name()='ProductBookingProperties']/*[local-name()='SoftwareInformation']/*[local-name()='SoftwareVersion']"/>
                            </urn:SoftwareVersion>
                        </urn:SoftwareInformation>
                        </xsl:if>
                        <xsl:if test="key('responseKey', concat(*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem']/*[local-name()='ProductBookingOrderLineItemNumber']))/reqSynOrdNum[string-length(normalize-space()) > 0]">
                        <urn:ReferenceInformation ReferenceType="SalesOrderReference">
                            <urn:DocumentReference>
                                <urn:DocumentIdentifier>
                                    <xsl:value-of select="key('responseKey', concat(*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem']/*[local-name()='ProductBookingOrderLineItemNumber']))/reqSynOrdNum"/>
                                </urn:DocumentIdentifier>
                            </urn:DocumentReference>
                        </urn:ReferenceInformation>
                        </xsl:if>
                    <xsl:if test="normalize-space(key('responseKey', concat(*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem']/*[local-name()='ProductBookingOrderLineItemNumber']))/respExceptions)!=''">
                        <xsl:for-each select="key('responseKey', concat(*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem']/*[local-name()='ProductBookingOrderLineItemNumber']))/respExceptions">
                            <urn:ResponseStatus>
                                <urn:ResponseStatusReasonIdentifier Agency="SUPPLIER">
                                   <xsl:choose>
                                    <xsl:when test="id">
                                        <xsl:value-of select="id"/>
                                    </xsl:when>
                                    <xsl:otherwise>null</xsl:otherwise>
                                </xsl:choose>
                                </urn:ResponseStatusReasonIdentifier>
                                <urn:ResponseStatusReasonDescription>
                                   <xsl:choose>
                                    <xsl:when test="description">
                                        <xsl:value-of select="description"/>
                                    </xsl:when>
                                    <xsl:otherwise>null</xsl:otherwise>
                                </xsl:choose>
                                </urn:ResponseStatusReasonDescription>
                                <urn:ResponseStatusComments>
                                    <xsl:choose>
                                   <xsl:when test="comments">
                                        <xsl:value-of select="comments"/>
                                    </xsl:when>
                                    <xsl:otherwise>null</xsl:otherwise>
                                </xsl:choose>
                                </urn:ResponseStatusComments>
                            </urn:ResponseStatus>
                        </xsl:for-each>
                    </xsl:if>
                    <xsl:if test = "key('responseKey', concat(*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem']/*[local-name()='ProductBookingOrderLineItemNumber']))/respSpcInst[string-length(normalize-space()) > 0]">
                        <xsl:for-each select="key('responseKey', concat(*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem']/*[local-name()='ProductBookingOrderLineItemNumber']))/respSpcInstr">
                            <urn:SpecialInstructions InstructionType="{InstructionType}">
                                <xsl:value-of select="SpecialInstructions"/>
                            </urn:SpecialInstructions>
                        </xsl:for-each>
                    </xsl:if>
                    </urn:ProductBookingResponseProperties>
                    <urn:ProductBookingResponsePartners>
                        <xsl:apply-templates select="*[local-name()='ProductBookingPartners']/*"/>
                    </urn:ProductBookingResponsePartners>
                    <urn:ProductBookingResponseDetails>
                        <xsl:for-each select="*[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem']">
                            <urn:ProductBookingResponseProductLineItem>
                                <urn:LineNumber>
                                    <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/reqSynOrdLineNum"/>
                                </urn:LineNumber>
                                <urn:LineItemType>Sale</urn:LineItemType>
                                <urn:ProductBookingOrderLineItemNumber>
                                    <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/reqCustOrdLineNum"/>
                                </urn:ProductBookingOrderLineItemNumber>
                                <urn:ProductIdentification>
                                    <urn:ProductIdentifier Agency="AGIIS-ProductID">
                                        <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/reqProdGTIN"/>
                                    </urn:ProductIdentifier>
                                    <urn:ProductName>
                                        <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respProdName"/>
                                    </urn:ProductName>
                                </urn:ProductIdentification>
                                <xsl:if test ="normalize-space(*[local-name()='ReferenceInformation'])!=''">   
                                <urn:ReferenceInformation ReferenceType="ContractNumber">
                                    <urn:DocumentReference>
                                        <urn:DocumentIdentifier>
                                            <xsl:value-of select="*[local-name()='ReferenceInformation']/*[local-name()='DocumentReference']/*[local-name()='DocumentIdentifier']"/>
                                        </urn:DocumentIdentifier>
                                    </urn:DocumentReference>
                                </urn:ReferenceInformation>
                                </xsl:if>
                                <urn:ProductQuantity>
                                    <urn:Measurement>
                                        <urn:MeasurementValue>
                                             <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|',*[local-name()='ProductBookingOrderLineItemNumber']))/reqProdQty"/>
                                        </urn:MeasurementValue>
                                        <urn:UnitOfMeasureCode Domain="UN-Rec-20">
                                            <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                        </urn:UnitOfMeasureCode>
                                    </urn:Measurement>
                                </urn:ProductQuantity>
                                <urn:PotentialShipDateTime>
                                    <urn:DateTimeInformation>
                                        <urn:DateTime DateTimeQualifier="On">
                                            <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/reqRDD"/>
                                        </urn:DateTime>
                                    </urn:DateTimeInformation>
                                </urn:PotentialShipDateTime>
                                <xsl:if test="normalize-space(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respExceptionsLine)!=''">
                                <xsl:for-each select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respExceptionsLine">
                                    <urn:ResponseStatus>
                                <urn:ResponseStatusReasonIdentifier Agency="SUPPLIER">
                                   <xsl:choose>
                                    <xsl:when test="id">
                                        <xsl:value-of select="id"/>
                                    </xsl:when>
                                    <xsl:otherwise>null</xsl:otherwise>
                                </xsl:choose>
                                </urn:ResponseStatusReasonIdentifier>
                                <urn:ResponseStatusReasonDescription>
                                   <xsl:choose>
                                    <xsl:when test="description">
                                        <xsl:value-of select="description"/>
                                    </xsl:when>
                                    <xsl:otherwise>null</xsl:otherwise>
                                </xsl:choose>
                                </urn:ResponseStatusReasonDescription>
                                <urn:ResponseStatusComments>
                                    <xsl:choose>
                                   <xsl:when test="comments">
                                        <xsl:value-of select="comments"/>
                                    </xsl:when>
                                    <xsl:otherwise>null</xsl:otherwise>
                                </xsl:choose>
                                </urn:ResponseStatusComments>
                            </urn:ResponseStatus>
                                </xsl:for-each>
                            </xsl:if>
                            </urn:ProductBookingResponseProductLineItem>
                        </xsl:for-each>
                        </urn:ProductBookingResponseDetails>
                        <xsl:if test ="*[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem'][normalize-space(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respExceptions) != '']  and normalize-space(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respExceptionsLine) != '' and $businessProcess = 'Pro-ProductBookingWS'">
                        <urn:RetailerOrderImpactSummary>
                            <xsl:for-each select="*[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem'][normalize-space(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respExceptionsLine) != '']">
                                <urn:RetailerResponseSummaryProductLineItem>
                                    <urn:ProductIdentification>
                                        <urn:ProductIdentifier Agency="AGIIS-ProductID">
                                            <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/reqProdGTIN"/>
                                        </urn:ProductIdentifier>
                                        <urn:ProductName>
                                                <xsl:choose>
                                                     <xsl:when test="string(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respProdName)">
                                                        <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respProdName"/>
                                                     </xsl:when>
                                                     <xsl:otherwise>
                                                      <xsl:text>Not Found</xsl:text>
                                                     </xsl:otherwise>
                                                </xsl:choose>
                                        </urn:ProductName>
                                    </urn:ProductIdentification>
                                    <urn:IncreaseDecreaseRetailerProductQuantity>
                                        <urn:IncreaseOrDecreaseType>
                                            <xsl:value-of select="*[local-name()='IncreaseOrDecrease']/*[local-name()='IncreaseOrDecreaseType']"/>
                                        </urn:IncreaseOrDecreaseType>
                                        <urn:Measurement>
                                            <urn:MeasurementValue>
                                                <xsl:choose>
                                                     <xsl:when test="string(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respPOQty)">
                                                        <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respPOQty"/>
                                                     </xsl:when>
                                                     <xsl:otherwise>
                                                      <xsl:text>0</xsl:text>
                                                     </xsl:otherwise>
                                                </xsl:choose>
                                            </urn:MeasurementValue>
                                            <urn:UnitOfMeasureCode Domain="UN-Rec-20">
                                                <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                            </urn:UnitOfMeasureCode>
                                        </urn:Measurement>
                                    </urn:IncreaseDecreaseRetailerProductQuantity>
                                   <urn:TotalRetailerOrderedProductQuantity>
                                        <urn:Measurement>
                                            <urn:MeasurementValue>
                                                <xsl:choose>
                                                     <xsl:when test="string(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respTotalPOQty)">
                                                        <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respTotalPOQty"/>
                                                     </xsl:when>
                                                     <xsl:otherwise>
                                                      <xsl:text>0</xsl:text>
                                                     </xsl:otherwise>
                                                </xsl:choose>
                                            </urn:MeasurementValue>
                                            <urn:UnitOfMeasureCode Domain="UN-Rec-20">
                                                <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                            </urn:UnitOfMeasureCode>
                                        </urn:Measurement>
                                    </urn:TotalRetailerOrderedProductQuantity>
                                     <urn:TotalBookingDemandQuantity>
                                        <urn:Measurement>
                                            <urn:MeasurementValue>
                                               <xsl:choose>
                                                     <xsl:when test="string(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respTotalGrowerQty)">
                                                        <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respTotalGrowerQty"/>
                                                     </xsl:when>
                                                     <xsl:otherwise>
                                                      <xsl:text>0</xsl:text>
                                                     </xsl:otherwise>
                                                </xsl:choose>
                                            </urn:MeasurementValue>
                                            <urn:UnitOfMeasureCode Domain="UN-Rec-20">
                                                <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                            </urn:UnitOfMeasureCode>
                                         </urn:Measurement>
                                    </urn:TotalBookingDemandQuantity>
                                    <urn:TotalLongShortPosition>
                                        <urn:LongShortPositionType>
                                                <xsl:choose>
                                                     <xsl:when test="string(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respAvailStatus)">
                                                        <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respAvailStatus"/>
                                                     </xsl:when>
                                                     <xsl:otherwise>
                                                        <xsl:text>Zero</xsl:text>
                                                     </xsl:otherwise>
                                                </xsl:choose>
                                        </urn:LongShortPositionType>
                                        <urn:Measurement>
                                            <urn:MeasurementValue>
                                                <xsl:choose>
                                                     <xsl:when test="string(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respLongShortQty)">
                                                        <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respLongShortQty"/>
                                                     </xsl:when>
                                                     <xsl:otherwise>
                                                        <xsl:text>0</xsl:text>
                                                     </xsl:otherwise>
                                                </xsl:choose>
                                            </urn:MeasurementValue>
                                            <urn:UnitOfMeasureCode Domain="UN-Rec-20">
                                                <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                            </urn:UnitOfMeasureCode>
                                        </urn:Measurement>
                                    </urn:TotalLongShortPosition>
                                </urn:RetailerResponseSummaryProductLineItem>
                            </xsl:for-each>
                        </urn:RetailerOrderImpactSummary>
                    </xsl:if>
                    
                </urn:ProductBookingResponseBody>
            </xsl:for-each>
        </urn:ProductBookingResponse>
    </xsl:template>

    <!-- Template for elements -->
   <xsl:template match="*[namespace-uri()='urn:cidx:names:specification:ces:schema:all:6.0']">
        <xsl:element name="urn:{local-name()}" namespace="urn:cidx:names:specification:ces:schema:all:6.0">
            <xsl:apply-templates select="@* | node()"/>
        </xsl:element>
    </xsl:template>

 <!-- Template for elements with dynamic namespace -->
    <xsl:template match="*[namespace-uri()=$Namespace]">
        <xsl:choose>
            <xsl:when test="$Prefix != '' and $Namespace != ''">
                <xsl:element name="{$Prefix}:{local-name()}" namespace="{$Namespace}"> <!-- Add dynamic prefix and namespace here -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:when>
            <xsl:otherwise>
                <xsl:element name="{local-name()}" namespace="{$Namespace}"> <!-- Handle without prefix but with dynamic namespace -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- Template for attributes -->
    <xsl:template match="@*">
        <xsl:attribute name="{local-name()}">
            <xsl:value-of select="."/>
        </xsl:attribute>
    </xsl:template>

    <!-- Generic template to copy elements as they are -->
    <xsl:template match="*">
        <xsl:element name="{local-name()}" namespace="{namespace-uri()}">
            <xsl:apply-templates select="@* | node()"/>
        </xsl:element>
    </xsl:template>
</xsl:stylesheet>