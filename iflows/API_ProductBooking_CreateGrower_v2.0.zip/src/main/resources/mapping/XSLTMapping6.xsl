<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:urn="urn:cidx:names:specification:ces:schema:all:6.0"
                xmlns:cidx="urn:cidx:names:DRAFT_0014:ces:schema:all:5:0"
                xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" exclude-result-prefixes="soapenv cidx">
    <xsl:output method="xml" indent="yes"/>
    
    <xsl:key name="distinctProduct" match="*[local-name()='OrderResponseSummaryProductLineItem']" use="*[local-name()='ProductIdentification']"/>
    <xsl:variable name="PartnerInformationPrefix" select="substring-before(name(//urn:OrderResponseBody/*[local-name()='OrderChangeResponseBody']/*[local-name()='OrderResponsePartners']/*[local-name()='Buyer']/*[local-name()='PartnerInformation']), ':')" />
<xsl:variable name="PartnerInformationNamespace" select="namespace-uri(//urn:OrderResponseBody/*[local-name()='OrderChangeResponseBody']/*[local-name()='OrderResponsePartners']/*[local-name()='Buyer']/*[local-name()='PartnerInformation'])" />
    <xsl:template match="/">
        <urn:OrderResponse>
            <urn:Header>
                <xsl:apply-templates select="//*[local-name()='OrderResponseBody']/*[local-name()='Header']/*"/>
            </urn:Header>
            <xsl:for-each select="//*[local-name()='OrderResponseBody']/*[local-name()='OrderChangeResponseBody']">
                <urn:OrderResponseBody>
                    <xsl:apply-templates select="node()"/>
                </urn:OrderResponseBody>
            </xsl:for-each>
            <xsl:if test="normalize-space(//*[local-name()='OrderResponseBody']/*[local-name()='OrderResponseSummary']/*[local-name()='OrderResponseSummaryProductLineItem']) != ''">
                <urn:OrderResponseSummary>
                    <xsl:for-each select="//*[local-name()='OrderResponseBody']//*[local-name()='OrderResponseSummaryProductLineItem'][generate-id() = generate-id(key('distinctProduct', *[local-name()='ProductIdentification'])[1])]">
                        <urn:OrderResponseSummaryProductLineItem>
                            <urn:LineNumber>
                                <xsl:value-of select="*[local-name()='PurchaseOrderLineItemNumber']"/>
                            </urn:LineNumber>
                            <urn:LineItemType>
                                <xsl:value-of select="*[local-name()='LineItemType']"/>
                            </urn:LineItemType>
                            <urn:PurchaseOrderLineItemNumber>
                                <xsl:value-of select="*[local-name()='PurchaseOrderLineItemNumber']"/>
                            </urn:PurchaseOrderLineItemNumber>
                            <urn:ProductIdentification>
                                <xsl:apply-templates select="*[local-name()='ProductIdentification']/*"/>
                            </urn:ProductIdentification>
                            <urn:ProductQuantity>
                                <xsl:apply-templates select="*[local-name()='ProductQuantity']/*"/>
                            </urn:ProductQuantity>
                            <urn:PackagingQuantity>
                                <xsl:apply-templates select="*[local-name()='PackagingQuantity']/*"/>
                            </urn:PackagingQuantity>
                            <urn:OrderedProductQuantity>
                                <xsl:apply-templates select="*[local-name()='OrderedProductQuantity']/*"/>
                            </urn:OrderedProductQuantity>
                            <urn:ExpectedReleaseQuantity>
                                <xsl:apply-templates select="*[local-name()='ExpectedReleaseQuantity']/*"/>
                            </urn:ExpectedReleaseQuantity>
                            <urn:ScheduleDateTimeInformation>
                                <xsl:apply-templates select="*[local-name()='ScheduleDateTimeInformation']/*"/>
                            </urn:ScheduleDateTimeInformation>
                            <urn:LineStatus>Changed</urn:LineStatus>
                        </urn:OrderResponseSummaryProductLineItem>
                    </xsl:for-each>
                </urn:OrderResponseSummary>
            </xsl:if>
        </urn:OrderResponse>
    </xsl:template>

    

    <!-- Template for elements with urn namespace -->
    <xsl:template match="*[namespace-uri()='urn:cidx:names:specification:ces:schema:all:6.0']">
        <xsl:element name="urn:{local-name()}" namespace="urn:cidx:names:specification:ces:schema:all:6.0">
            <xsl:apply-templates select="@* | node()"/>
        </xsl:element>
    </xsl:template>

    <!-- Template for elements with dynamic ns1 namespace -->
    <xsl:template match="*[namespace-uri()=$PartnerInformationNamespace]">
        <xsl:choose>
            <xsl:when test="$PartnerInformationPrefix != '' and $PartnerInformationNamespace != ''">
                <xsl:element name="{$PartnerInformationPrefix}:{local-name()}" namespace="{$PartnerInformationNamespace}"> <!-- Add dynamic prefix and namespace here -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:when>
            <xsl:otherwise>
                <xsl:element name="{local-name()}" namespace="{$PartnerInformationNamespace}"> <!-- Handle without prefix but with dynamic namespace -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    
    <!-- Template for elements without a namespace -->
    <xsl:template match="*[namespace-uri()='']">
        <xsl:element name="{local-name()}">
            <xsl:apply-templates select="@* | node()"/>
        </xsl:element>
    </xsl:template>
    
    <!-- Template for attributes -->
    <xsl:template match="@*">
        <xsl:attribute name="{local-name()}">
            <xsl:value-of select="."/>
        </xsl:attribute>
    </xsl:template>
</xsl:stylesheet>