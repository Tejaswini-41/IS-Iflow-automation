<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:cidx5_3="urn:cidx:names:specification:ces:schema:all:5:3"
                xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" exclude-result-prefixes="soapenv">
    <xsl:output method="xml" indent="yes"/>

    <xsl:variable name="currDateTime" select="concat(substring(current-dateTime(), 1, 10), 'T', substring(current-dateTime(), 12, 8), 'Z')"/>
    <xsl:key name="responseKey" match="response" use="concat(reqCustOrdNum, '|', reqCustOrdLineNum)"/>
    <xsl:variable name="Prefix" select="substring-before(name(root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking']), ':')"/>
    <xsl:variable name="Namespace" select="namespace-uri(root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking'])"/>
    

    <xsl:template match="/">
        <cidx5_3:ProductBookingResponse>
            <cidx5_3:Header>
                <cidx5_3:ThisDocumentIdentifier>
                    <cidx5_3:DocumentIdentifier>
                        <xsl:value-of select="root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking']/*[local-name()='Header']/*[local-name()='ThisDocumentIdentifier']/*[local-name()='DocumentIdentifier']"/>
                    </cidx5_3:DocumentIdentifier>
                </cidx5_3:ThisDocumentIdentifier>
                <cidx5_3:ThisDocumentDateTime>
                    <cidx5_3:DateTime DateTimeQualifier="On">
                        <xsl:value-of select="$currDateTime"/>
                    </cidx5_3:DateTime>
                </cidx5_3:ThisDocumentDateTime>
                <cidx5_3:From>
                    <xsl:apply-templates select="root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking']/*[local-name()='Header']/*[local-name()='To']/*"/>
                </cidx5_3:From>
                <cidx5_3:To>
                    <xsl:apply-templates select="root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking']/*[local-name()='Header']/*[local-name()='From']/*"/>
                </cidx5_3:To>
            </cidx5_3:Header>
            <xsl:for-each select="root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='ProductBooking']/*[local-name()='ProductBookingBody']">
                <cidx5_3:ProductBookingResponseBody>
                    <cidx5_3:ProductBookingResponseProperties>
                        <cidx5_3:ProductBookingType>
                            <xsl:value-of select="*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingType']"/>
                        </cidx5_3:ProductBookingType>
                        <cidx5_3:ProductBookingOrderNumber>
                            <xsl:value-of select="*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber']"/>
                        </cidx5_3:ProductBookingOrderNumber>
                        <cidx5_3:ProductBookingOrderTypeCode>
                            <xsl:value-of select="*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderTypeCode']"/>
                        </cidx5_3:ProductBookingOrderTypeCode>
                        <cidx5_3:ProductBookingOrderIssuedDate>
                            <xsl:apply-templates select="*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderIssuedDate']/*"/>
                        </cidx5_3:ProductBookingOrderIssuedDate>
                        <cidx5_3:LanguageCode Domain="ISO-639-2T">
                            <xsl:value-of select="*[local-name()='ProductBookingProperties']/*[local-name()='LanguageCode']"/>
                        </cidx5_3:LanguageCode>
                        <cidx5_3:CurrencyCode Domain="ISO-4217">
                            <xsl:value-of select="*[local-name()='ProductBookingProperties']/*[local-name()='CurrencyCode']"/>
                        </cidx5_3:CurrencyCode>
                        <cidx5_3:BuyerSequenceNumber>
                            <xsl:value-of select="format-number(*[local-name()='ProductBookingProperties']/*[local-name()='BuyerSequenceNumber'], '00000000')"/>
                        </cidx5_3:BuyerSequenceNumber>
                        <cidx5_3:SoftwareInformation>
                            <cidx5_3:SoftwareSource>
                                <xsl:value-of select="*[local-name()='ProductBookingProperties']/*[local-name()='SoftwareInformation']/*[local-name()='SoftwareSource']"/>
                            </cidx5_3:SoftwareSource>
                            <cidx5_3:SoftwareVersion>
                                <xsl:value-of select="*[local-name()='ProductBookingProperties']/*[local-name()='SoftwareInformation']/*[local-name()='SoftwareVersion']"/>
                            </cidx5_3:SoftwareVersion>
                        </cidx5_3:SoftwareInformation>
                    <xsl:if test="key('responseKey', concat(*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem']/*[local-name()='ProductBookingOrderLineItemNumber']))/reqSynOrdNum">
                        <cidx5_3:ReferenceInformation ReferenceType="SalesOrderReference">
                            <cidx5_3:DocumentReference>
                                <cidx5_3:DocumentIdentifier>
                                    <xsl:value-of select="key('responseKey', concat(*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem']/*[local-name()='ProductBookingOrderLineItemNumber']))/reqSynOrdNum"/>
                                </cidx5_3:DocumentIdentifier>
                            </cidx5_3:DocumentReference>
                        </cidx5_3:ReferenceInformation>
                    </xsl:if>
                        <xsl:if test="normalize-space(key('responseKey', concat(*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem']/*[local-name()='ProductBookingOrderLineItemNumber']))/respExceptions)!= ''">
                            <xsl:for-each select="key('responseKey', concat(*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem']/*[local-name()='ProductBookingOrderLineItemNumber']))/respExceptions">
                                <cidx5_3:ResponseStatus>
                                    <cidx5_3:ResponseStatusReasonIdentifier Agency="SUPPLIER">
                                        <xsl:choose>
                                            <xsl:when test="id">
                                                <xsl:value-of select="id"/>
                                            </xsl:when>
                                            <xsl:otherwise>null</xsl:otherwise>
                                        </xsl:choose>
                                    </cidx5_3:ResponseStatusReasonIdentifier>
                                    <cidx5_3:ResponseStatusReasonDescription>
                                        <xsl:choose>
                                            <xsl:when test="description">
                                                <xsl:value-of select="description"/>
                                            </xsl:when>
                                            <xsl:otherwise>null</xsl:otherwise>
                                        </xsl:choose>
                                    </cidx5_3:ResponseStatusReasonDescription>
                                    <cidx5_3:ResponseStatusComments>
                                        <xsl:choose>
                                            <xsl:when test="comments">
                                                <xsl:value-of select="comments"/>
                                            </xsl:when>
                                            <xsl:otherwise>null</xsl:otherwise>
                                        </xsl:choose>
                                    </cidx5_3:ResponseStatusComments>
                                </cidx5_3:ResponseStatus>
                            </xsl:for-each>
                        </xsl:if>
                        <xsl:if test="key('responseKey', concat(*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem']/*[local-name()='ProductBookingOrderLineItemNumber']))/respSpcInstr[string-length(normalize-space()) > 0]">
                            <xsl:for-each select="key('responseKey', concat(*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem']/*[local-name()='ProductBookingOrderLineItemNumber']))/respSpcInstr">
                                <cidx5_3:SpecialInstructions InstructionType="{InstructionType}">
                                    <xsl:value-of select="SpecialInstructions"/>
                                </cidx5_3:SpecialInstructions>
                            </xsl:for-each>
                        </xsl:if>
                    </cidx5_3:ProductBookingResponseProperties>
                    <cidx5_3:ProductBookingResponsePartners>
                        <xsl:apply-templates select="*[local-name()='ProductBookingPartners']/*"/>
                    </cidx5_3:ProductBookingResponsePartners>
                    <cidx5_3:ProductBookingResponseDetails>
                        <xsl:for-each select="*[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem']">
                            <cidx5_3:ProductBookingResponseProductLineItem>
                                <cidx5_3:LineNumber>
                                    <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/reqSynOrdLineNum"/>
                                </cidx5_3:LineNumber>
                                <cidx5_3:LineItemType>Sale</cidx5_3:LineItemType>
                                <cidx5_3:ProductBookingOrderLineItemNumber>
                                    <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/reqCustOrdLineNum"/>
                                </cidx5_3:ProductBookingOrderLineItemNumber>
                                <cidx5_3:ProductIdentification>
                                    <cidx5_3:ProductIdentifier Agency="AGIIS-ProductID">
                                        <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/reqProdGTIN"/>
                                    </cidx5_3:ProductIdentifier>
                                </cidx5_3:ProductIdentification>
                                <cidx5_3:ReferenceInformation ReferenceType="ContractNumber">
                                    <cidx5_3:DocumentReference>
                                        <cidx5_3:DocumentIdentifier>
                                            <xsl:value-of select="*[local-name()='ReferenceInformation']/*[local-name()='DocumentReference']/*[local-name()='DocumentIdentifier']"/>
                                        </cidx5_3:DocumentIdentifier>
                                    </cidx5_3:DocumentReference>
                                </cidx5_3:ReferenceInformation>
                                <cidx5_3:ProductQuantity>
                                    <cidx5_3:Measurement>
                                        <cidx5_3:MeasurementValue>
                                            <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/reqProdQty"/>
                                        </cidx5_3:MeasurementValue>
                                        <cidx5_3:UnitOfMeasureCode Domain="UN-Rec-20">
                                            <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                        </cidx5_3:UnitOfMeasureCode>
                                    </cidx5_3:Measurement>
                                </cidx5_3:ProductQuantity>
                                <cidx5_3:PotentialShipDateTime>
                                    <cidx5_3:DateTimeInformation>
                                        <cidx5_3:DateTime DateTimeQualifier="On">
                                            <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/reqRDD"/>
                                        </cidx5_3:DateTime>
                                    </cidx5_3:DateTimeInformation>
                                </cidx5_3:PotentialShipDateTime>
                               <xsl:if test="normalize-space( key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respExceptionsLine)!= ''">
                                    <xsl:for-each select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respExceptionsLine">
                                        <cidx5_3:ResponseStatus>
                                            <cidx5_3:ResponseStatusReasonIdentifier Agency="SUPPLIER">
                                                <xsl:choose>
                                                    <xsl:when test="id">
                                                        <xsl:value-of select="id"/>
                                                    </xsl:when>
                                                    <xsl:otherwise>null</xsl:otherwise>
                                                </xsl:choose>
                                            </cidx5_3:ResponseStatusReasonIdentifier>
                                            <cidx5_3:ResponseStatusReasonDescription>
                                                <xsl:choose>
                                                    <xsl:when test="description">
                                                        <xsl:value-of select="description"/>
                                                    </xsl:when>
                                                    <xsl:otherwise>null</xsl:otherwise>
                                                </xsl:choose>
                                            </cidx5_3:ResponseStatusReasonDescription>
                                            <cidx5_3:ResponseStatusComments>
                                                <xsl:choose>
                                                    <xsl:when test="comments">
                                                        <xsl:value-of select="comments"/>
                                                    </xsl:when>
                                                    <xsl:otherwise>null</xsl:otherwise>
                                                </xsl:choose>
                                            </cidx5_3:ResponseStatusComments>
                                        </cidx5_3:ResponseStatus>
                                    </xsl:for-each>
                                </xsl:if>
                            </cidx5_3:ProductBookingResponseProductLineItem>
                        </xsl:for-each>
                        </cidx5_3:ProductBookingResponseDetails>
                        <xsl:if test ="*[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem'][not(normalize-space(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respExceptions)!= '' and not(contains(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respExceptions/id, '000') or contains(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respExceptions/id, '098')))]">
                        <cidx5_3:RetailerOrderImpactSummary>
                            <xsl:for-each select="*[local-name()='ProductBookingDetails']/*[local-name()='ProductBookingProductLineItem'][not(normalize-space(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respExceptionsLine)!= '' and not(contains(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respExceptionsLine/id, '000') or contains(key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respExceptionsLine/id, '098')))]">
                                <cidx5_3:RetailerResponseSummaryProductLineItem>
                                    <cidx5_3:ProductIdentification>
                                        <cidx5_3:ProductIdentifier Agency="AGIIS-ProductID">
                                            <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/reqProdGTIN"/>
                                        </cidx5_3:ProductIdentifier>
                                        <cidx5_3:ProductName>
                                            <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respProdName"/>
                                        </cidx5_3:ProductName>
                                    </cidx5_3:ProductIdentification>
                                    <cidx5_3:IncreaseDecreaseRetailerProductQuantity>
                                        <cidx5_3:IncreaseOrDecreaseType>
                                            <xsl:value-of select="*[local-name()='IncreaseOrDecrease']/*[local-name()='IncreaseOrDecreaseType']"/>
                                        </cidx5_3:IncreaseOrDecreaseType>
                                        <cidx5_3:Measurement>
                                            <cidx5_3:MeasurementValue>
                                                <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respPOQty"/>
                                            </cidx5_3:MeasurementValue>
                                            <cidx5_3:UnitOfMeasureCode Domain="UN-Rec-20">
                                                <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                            </cidx5_3:UnitOfMeasureCode>
                                        </cidx5_3:Measurement>
                                    </cidx5_3:IncreaseDecreaseRetailerProductQuantity>
                                    <cidx5_3:TotalBookingDemandQuantity>
                                        <cidx5_3:Measurement>
                                            <cidx5_3:MeasurementValue>
                                                <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respTotalGrowerQty"/>
                                            </cidx5_3:MeasurementValue>
                                            <cidx5_3:UnitOfMeasureCode Domain="UN-Rec-20">
                                                <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                            </cidx5_3:UnitOfMeasureCode>
                                         </cidx5_3:Measurement>
                                    </cidx5_3:TotalBookingDemandQuantity>
                                    <cidx5_3:TotalRetailerOrderedProductQuantity>
                                        <cidx5_3:Measurement>
                                            <cidx5_3:MeasurementValue>
                                                <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respTotalPOQty"/>
                                            </cidx5_3:MeasurementValue>
                                            <cidx5_3:UnitOfMeasureCode Domain="UN-Rec-20">
                                                <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                            </cidx5_3:UnitOfMeasureCode>
                                        </cidx5_3:Measurement>
                                    </cidx5_3:TotalRetailerOrderedProductQuantity>
                                    <cidx5_3:TotalLongShortPosition>
                                        <cidx5_3:LongShortPositionType>
                                            <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respAvailStatus"/>
                                        </cidx5_3:LongShortPositionType>
                                        <cidx5_3:Measurement>
                                            <cidx5_3:MeasurementValue>
                                                <xsl:value-of select="key('responseKey', concat(../../*[local-name()='ProductBookingProperties']/*[local-name()='ProductBookingOrderNumber'], '|', *[local-name()='ProductBookingOrderLineItemNumber']))/respLongShortQty"/>
                                            </cidx5_3:MeasurementValue>
                                            <cidx5_3:UnitOfMeasureCode Domain="UN-Rec-20">
                                                <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                            </cidx5_3:UnitOfMeasureCode>
                                        </cidx5_3:Measurement>
                                    </cidx5_3:TotalLongShortPosition>
                                </cidx5_3:RetailerResponseSummaryProductLineItem>
                            </xsl:for-each>
                        </cidx5_3:RetailerOrderImpactSummary>
                        </xsl:if>
                    
                </cidx5_3:ProductBookingResponseBody>
            </xsl:for-each>
        </cidx5_3:ProductBookingResponse>
    </xsl:template>

    <xsl:template match="*[namespace-uri()='urn:cidx:names:specification:ces:schema:all:5:3']">
        <xsl:element name="cidx:{local-name()}" namespace="urn:cidx:names:specification:ces:schema:all:5:3">
            <xsl:apply-templates select="@* | node()"/>
        </xsl:element>
    </xsl:template>

   
 <!-- Template for elements with dynamic namespace -->
    <xsl:template match="*[namespace-uri()=$Namespace]">
        <xsl:choose>
            <xsl:when test="$Prefix != '' and $Namespace != ''">
                <xsl:element name="{$Prefix}:{local-name()}" namespace="{$Namespace}"> <!-- Add dynamic prefix and namespace here -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:when>
            <xsl:otherwise>
                <xsl:element name="{local-name()}" namespace="{$Namespace}"> <!-- Handle without prefix but with dynamic namespace -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- Template for attributes -->
    <xsl:template match="@*">
        <xsl:attribute name="{local-name()}">
            <xsl:value-of select="."/>
        </xsl:attribute>
    </xsl:template>

    <!-- Generic template to copy elements as they are -->
    <xsl:template match="*">
        <xsl:element name="{local-name()}" namespace="{namespace-uri()}">
            <xsl:apply-templates select="@* | node()"/>
        </xsl:element>
    </xsl:template>
</xsl:stylesheet>