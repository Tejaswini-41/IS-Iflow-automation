<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:urn="urn:cidx:names:specification:ces:schema:all:6.0"
                xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" exclude-result-prefixes="soapenv">
    <xsl:output method="xml" indent="yes"/>

    <xsl:variable name="currDateTime" select="concat(substring(current-dateTime(), 1, 10), 'T', substring(current-dateTime(), 12, 8), 'Z')"/>
    <xsl:key name="responseKey" match="response" use="concat(reqCustOrdNum, '|', reqCustOrdLineNum)"/>
    <xsl:variable name="OrderChangePrefix" select="substring-before(name(root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange']), ':')"/>
    <xsl:variable name="OrderChangeNamespace" select="namespace-uri(root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange'])"/>
    <xsl:variable name="CidxPrefix" select="substring-before(name(root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange']/*[local-name()='Header']), ':')"/>
    <xsl:variable name="CidxNamespace" select="namespace-uri(root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange']/*[local-name()='Header'])"/>
    <xsl:template match="/">
    
        <urn:OrderResponseBody>
            <urn:Header>
                <urn:ThisDocumentIdentifier>
                    <urn:DocumentIdentifier>
                        <xsl:value-of select="root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange']/*[local-name()='Header']/*[local-name()='ThisDocumentIdentifier']/*[local-name()='DocumentIdentifier']"/>
                </urn:DocumentIdentifier>
                </urn:ThisDocumentIdentifier>
                <urn:ThisDocumentDateTime>
                    <urn:DateTime DateTimeQualifier="On">
                        <xsl:value-of select="$currDateTime"/>
                    </urn:DateTime>
                </urn:ThisDocumentDateTime>
                <urn:From>
                    <xsl:apply-templates select="root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange']/*[local-name()='Header']/*[local-name()='To']/*"/>
                </urn:From>
                <urn:To>
                    <xsl:apply-templates select="root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange']/*[local-name()='Header']/*[local-name()='From']/*"/>
                </urn:To>
            </urn:Header>
            <xsl:for-each select="root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange']/*[local-name()='OrderChangeBody']">
                <urn:OrderChangeResponseBody>
                    <urn:OrderResponseProperties>
                        <urn:PurchaseOrderNumber>
                            <xsl:apply-templates select="*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*"/>
                        </urn:PurchaseOrderNumber>
                        <urn:PurchaseOrderIssuedDate>
                            <xsl:apply-templates select="*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderIssuedDate']/*"/>
                        </urn:PurchaseOrderIssuedDate>
                        <urn:LanguageCode>
                            <xsl:value-of select="*[local-name()='OrderChangeProperties']/*[local-name()='LanguageCode']"/>
                        </urn:LanguageCode>
                        <urn:CurrencyCode>
                            <xsl:value-of select="*[local-name()='OrderChangeProperties']/*[local-name()='CurrencyCode']"/>
                        </urn:CurrencyCode>
                        <urn:BuyerSequenceNumber>
                            <xsl:value-of select="*[local-name()='OrderChangeProperties']/*[local-name()='BuyerSequenceNumber']"/>
                        </urn:BuyerSequenceNumber>
                        <urn:SellerSequenceNumber>
                            <xsl:value-of select="*[local-name()='OrderChangeProperties']/*[local-name()='SellerSequenceNumber']"/>
                        </urn:SellerSequenceNumber>
                    <xsl:if test="key('responseKey', concat(*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='OrderChangeDetails']/*[local-name()='OrderChangeProductLineItem']/*[local-name()='PurchaseOrderLineItemNumber']))/reqSynOrdNum[string-length(normalize-space()) > 0]">
                        <urn:ReferenceInformation ReferenceType="SalesOrderReference">
                            <urn:DocumentReference>
                                <urn:DocumentIdentifier>
                                    <xsl:value-of select="key('responseKey', concat(*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='OrderChangeDetails']/*[local-name()='OrderChangeProductLineItem']/*[local-name()='PurchaseOrderLineItemNumber']))/reqSynOrdNum"/>
                                </urn:DocumentIdentifier>
                            </urn:DocumentReference>
                        </urn:ReferenceInformation>
                    </xsl:if>
                    <xsl:if test="key('responseKey', concat(*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='OrderChangeDetails']/*[local-name()='OrderChangeProductLineItem']/*[local-name()='PurchaseOrderLineItemNumber']))/respSpcInstr[string-length(normalize-space()) > 0]">
                        <xsl:for-each select="key('responseKey', concat(*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='OrderChangeDetails']/*[local-name()='OrderChangeProductLineItem']/*[local-name()='PurchaseOrderLineItemNumber']))/respSpcInstr">
                            <urn:SpecialInstructions InstructionType="{InstructionType}">
                                <xsl:value-of select="SpecialInstructions"/>
                            </urn:SpecialInstructions>
                        </xsl:for-each>
                    </xsl:if>
                    <xsl:if test="normalize-space(key('responseKey', concat(*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='OrderChangeDetails']/*[local-name()='OrderChangeProductLineItem']/*[local-name()='PurchaseOrderLineItemNumber']))/respExceptions)!= ''">
                        <xsl:for-each select="key('responseKey', concat(*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='OrderChangeDetails']/*[local-name()='OrderChangeProductLineItem']/*[local-name()='PurchaseOrderLineItemNumber']))/respExceptions">
                            <urn:ResponseStatus>
                                <ResponseStatusReasonIdentifier Agency="{if(id = '000' or id = '098') then 'SUPPLIER' else 'ECMS'}">
                                    <xsl:value-of select="if(id = '000' or id = '098') then id else 'E'"/>
                                </ResponseStatusReasonIdentifier>
                                <ResponseStatusReasonDescription>
                                    <xsl:value-of select="description"/>
                                </ResponseStatusReasonDescription>
                                <ResponseStatusReasonComments>
                                    <xsl:value-of select="comments"/>
                                </ResponseStatusReasonComments>
                            </urn:ResponseStatus>
                        </xsl:for-each>
                    </xsl:if>
                    </urn:OrderResponseProperties>
                    <urn:OrderResponsePartners>
                        <xsl:apply-templates select="*[local-name()='OrderChangePartners']/*"/>
                    </urn:OrderResponsePartners>
                    <urn:OrderResponseDetails>
                        <xsl:for-each select="*[local-name()='OrderChangeDetails']/*[local-name()='OrderChangeProductLineItem']">
                            <urn:OrderResponseProductLineItem>
                                <urn:LineNumber>
                                    <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/reqSynOrdLineNum"/>
                                </urn:LineNumber>
                                <urn:LineStatus>
                                    <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/reqType"/>
                                </urn:LineStatus>
                                <urn:LineItemType>Sale</urn:LineItemType>
                                <urn:PurchaseOrderLineItemNumber>
                                    <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/reqCustOrdLineNum"/>
                                </urn:PurchaseOrderLineItemNumber>
                                <urn:ProductIdentification>
                                    <urn:ProductIdentifier Agency="AGIIS-ProductID">
                                        <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/reqProdGTIN"/>
                                    </urn:ProductIdentifier>
                                </urn:ProductIdentification>
                                <urn:ProductQuantity>
                                    <urn:Measurement>
                                        <urn:MeasurementValue>
                                            <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/reqProdQty"/>
                                        </urn:MeasurementValue>
                                        <urn:UnitOfMeasureCode Domain="UN-Rec-20">
                                            <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                        </urn:UnitOfMeasureCode>
                                    </urn:Measurement>
                                </urn:ProductQuantity>
                                <urn:PackagingQuantity>
                                    <urn:Measurement>
                                        <urn:MeasurementValue>
                                            <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/reqProdQty"/>
                                        </urn:MeasurementValue>
                                        <urn:UnitOfMeasureCode Domain="UN-Rec-20">
                                            <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                        </urn:UnitOfMeasureCode>
                                    </urn:Measurement>
                                </urn:PackagingQuantity>
                                <urn:ScheduleDateTimeInformation ScheduleType="{*[local-name()='ScheduleDateTimeInformation']/@ScheduleType}">
                                    <urn:DateTimeInformation>
                                        <urn:DateTime DateTimeQualifier="On">
                                            <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/reqRDD"/>
                                        </urn:DateTime>
                                    </urn:DateTimeInformation>
                                </urn:ScheduleDateTimeInformation>
                                <xsl:if test="normalize-space(key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/respExceptionsLine)!= ''">
                                    <xsl:for-each select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/respExceptionsLine">
                                        <urn:ResponseStatus>
                                            <urn:ResponseStatusReasonIdentifier Agency="{if(id = '000' or id = '098') then 'SUPPLIER' else 'ECMS'}">
                                                <xsl:value-of select="if(id = '000' or id = '098') then id else 'E'"/>
                                            </urn:ResponseStatusReasonIdentifier>
                                            <urn:ResponseStatusReasonDescription>
                                                <xsl:value-of select="description"/>
                                            </urn:ResponseStatusReasonDescription>
                                            <urn:ResponseStatusReasonComments>
                                                <xsl:value-of select="comments"/>
                                            </urn:ResponseStatusReasonComments>
                                        </urn:ResponseStatus>
                                    </xsl:for-each>
                                </xsl:if>
                            </urn:OrderResponseProductLineItem>
                        </xsl:for-each>
                    </urn:OrderResponseDetails>
                </urn:OrderChangeResponseBody>
            </xsl:for-each>
            <xsl:for-each select="root/soapenv:Envelope/soapenv:Body/*[local-name()='inboundData']/*[local-name()='xmlPayload']/*[local-name()='OrderChange']/*[local-name()='OrderChangeBody']">
    <xsl:if test="not(
        normalize-space(key('responseKey', concat(*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='OrderChangeDetails']/*[local-name()='OrderChangeProductLineItem']/*[local-name()='PurchaseOrderLineItemNumber']))/respExceptions)!= '' and not(contains(key('responseKey', concat(*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='OrderChangeDetails']/*[local-name()='OrderChangeProductLineItem']/*[local-name()='PurchaseOrderLineItemNumber']))/respExceptions/id, '000') or contains(key('responseKey', concat(*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='OrderChangeDetails']/*[local-name()='OrderChangeProductLineItem']/*[local-name()='PurchaseOrderLineItemNumber']))/respExceptions/id, '098')
        )
    )">
        <urn:OrderResponseSummary>
            <xsl:for-each select="*[local-name()='OrderChangeDetails']/*[local-name()='OrderChangeProductLineItem']">
                <xsl:if test="not(normalize-space(key('responseKey', concat(*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/respExceptionsLine)!= '' and not(contains(key('responseKey', concat(*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/respExceptionsLine/id, '000') or contains(key('responseKey', concat(*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/respExceptionsLine/id, '098')))">
                    <urn:OrderResponseSummaryProductLineItem>
                        <urn:LineNumber>
                            <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/reqSynOrdLineNum"/>
                        </urn:LineNumber>
                        <urn:LineItemType>Sale</urn:LineItemType>
                        <urn:PurchaseOrderLineItemNumber>
                            <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/reqCustOrdLineNum"/>
                        </urn:PurchaseOrderLineItemNumber>
                        <urn:ProductIdentification>
                            <urn:ProductIdentifier Agency="AGIIS-ProductID">
                                <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/reqProdGTIN"/>
                            </urn:ProductIdentifier>
                            <urn:ProductName>
                                <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/respProdName"/>
                            </urn:ProductName>
                        </urn:ProductIdentification>
                        <urn:ProductQuantity>
                            <urn:Measurement>
                                <urn:MeasurementValue>
                                    <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/respPOQty"/>
                                </urn:MeasurementValue>
                                <urn:UnitOfMeasureCode Domain="UN-Rec-20">
                                    <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                </urn:UnitOfMeasureCode>
                            </urn:Measurement>
                        </urn:ProductQuantity>
                        <urn:PackagingQuantity>
                            <urn:Measurement>
                                <urn:MeasurementValue>
                                    <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/respTotalPOQty"/>
                                </urn:MeasurementValue>
                                <urn:UnitOfMeasureCode Domain="UN-Rec-20">
                                    <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                </urn:UnitOfMeasureCode>
                            </urn:Measurement>
                        </urn:PackagingQuantity>
                        <urn:OrderedProductQuantity>
                            <urn:Measurement>
                                <urn:MeasurementValue>
                                    <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/respTotalGrowerQty"/>
                                </urn:MeasurementValue>
                                <urn:UnitOfMeasureCode Domain="UN-Rec-20">
                                    <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                </urn:UnitOfMeasureCode>
                            </urn:Measurement>
                        </urn:OrderedProductQuantity>
                        <urn:ExpectedReleaseQuantity>
                            <urn:Measurement>
                                <urn:MeasurementValue>
                                    <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/respLongShortQty"/>
                                </urn:MeasurementValue>
                                <urn:UnitOfMeasureCode Domain="UN-Rec-20">
                                    <xsl:value-of select="*[local-name()='ProductQuantity']/*[local-name()='Measurement']/*[local-name()='UnitOfMeasureCode']"/>
                                </urn:UnitOfMeasureCode>
                            </urn:Measurement>
                        </urn:ExpectedReleaseQuantity>
                        <urn:ScheduleDateTimeInformation ScheduleType="{*[local-name()='ScheduleDateTimeInformation']/@ScheduleType}">
                            <urn:DateTimeInformation>
                                <urn:DateTime DateTimeQualifier="On">
                                    <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/reqRDD"/>
                                </urn:DateTime>
                            </urn:DateTimeInformation>
                        </urn:ScheduleDateTimeInformation>
                        <urn:LineStatus>
                            <xsl:value-of select="key('responseKey', concat(../../*[local-name()='OrderChangeProperties']/*[local-name()='PurchaseOrderNumber']/*[local-name()='DocumentIdentifier'], '|', *[local-name()='PurchaseOrderLineItemNumber']))/reqType"/>
                        </urn:LineStatus>
                    </urn:OrderResponseSummaryProductLineItem>
                </xsl:if>
            </xsl:for-each>
        </urn:OrderResponseSummary>
    </xsl:if>
</xsl:for-each>
        </urn:OrderResponseBody>
        </xsl:template>

         <!-- Template for elements with dynamic cidx namespace -->
    <xsl:template match="*[namespace-uri()=$CidxNamespace]">
        <xsl:choose>
            <xsl:when test="$CidxPrefix != '' and $CidxNamespace != ''">
                <xsl:element name="{$CidxPrefix}:{local-name()}" namespace="{$CidxNamespace}"> <!-- Add dynamic prefix and namespace here -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:when>
            <xsl:otherwise>
                <xsl:element name="{local-name()}" namespace="{$CidxNamespace}"> <!-- Handle without prefix but with dynamic namespace -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <!-- Template for elements with dynamic ns1 namespace -->
    <xsl:template match="*[namespace-uri()=$OrderChangeNamespace]">
        <xsl:choose>
            <xsl:when test="$OrderChangePrefix != '' and $OrderChangeNamespace != ''">
                <xsl:element name="{$OrderChangePrefix}:{local-name()}" namespace="{$OrderChangeNamespace}"> <!-- Add dynamic prefix and namespace here -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:when>
            <xsl:otherwise>
                <xsl:element name="{local-name()}" namespace="{$OrderChangeNamespace}"> <!-- Handle without prefix but with dynamic namespace -->
                    <xsl:apply-templates select="@* | node()"/>
                </xsl:element>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    
    <!-- Template for attributes -->
    <xsl:template match="@*">
        <xsl:attribute name="{local-name()}">
            <xsl:value-of select="."/>
        </xsl:attribute>
    </xsl:template>
</xsl:stylesheet>